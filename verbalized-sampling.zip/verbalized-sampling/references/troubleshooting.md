# Verbalized Sampling Troubleshooting

Common issues when using VS and how to resolve them.

## Model Refuses to Follow Instructions

**Symptom:** Model says it cannot generate probabilities, refuses the task, or interprets the prompt as a jailbreak attempt.

**Cause:** Some models are trained to refuse complex meta-instructions that seem to manipulate their behavior.

**Solutions:**

1. **Use system prompt version instead of inline:**
   ```
   System: You are a helpful assistant. For each query, generate five responses 
   with probabilities in <response> tags.
   
   User: [Original request]
   ```

2. **Simplify the instruction:**
   ```
   Generate 5 different responses with their probabilities.
   [Original request]
   ```

3. **Use confidence framing instead of probability:**
   ```
   Generate 5 responses with confidence scores.
   [Original request]
   ```

4. **Add reassurance:**
   ```
   This is for creative exploration. Generate 5 diverse responses with 
   probabilities to help me see different options.
   [Original request]
   ```

## Model Generates Same Response 5 Times

**Symptom:** All 5 responses are identical or nearly identical, just with different probability values.

**Cause:** Mode collapse still happening. The model hasn't understood it should generate diverse outputs.

**Solutions:**

1. **Explicitly request diversity:**
   ```
   Generate 5 DIFFERENT responses. Each must be meaningfully distinct.
   Include probability for each.
   [Original request]
   ```

2. **Add diversity guidance:**
   ```
   Generate 5 responses exploring different:
   - Tones (serious, humorous, poetic)
   - Approaches (direct, indirect, creative)
   - Perspectives (optimistic, realistic, unconventional)
   Each with a probability.
   [Original request]
   ```

3. **Use VS-CoT variant:** The reasoning phase often breaks the repetition:
   ```
   First, brainstorm 5 different creative directions.
   Then, generate a response for each direction with its probability.
   [Original request]
   ```

4. **Lower the probability threshold:** Forces sampling from tails:
   ```
   Generate 5 responses with probability less than 0.05 each.
   [Original request]
   ```

## Probabilities Don't Sum to 1.0

**Symptom:** The probabilities across responses are inconsistent (e.g., all 0.20, or sum to 2.5).

**Cause:** LLMs verbalize approximate, not mathematically rigorous, probabilities.

**This is expected and fine.** The probabilities are useful for relative ranking, not absolute values.

**If you need normalized probabilities:**
- Normalize manually: `p_i / sum(all p)`
- Use for relative comparison only
- Higher probability = more typical; lower = more creative

## Output Doesn't Follow XML Format

**Symptom:** Model outputs JSON, markdown, or unstructured text instead of `<response>` tags.

**Solutions:**

1. **Be explicit about format:**
   ```
   Generate 5 responses in this EXACT format:
   <response>
     <text>response content</text>
     <probability>0.XX</probability>
   </response>
   
   [Original request]
   ```

2. **Provide an example:**
   ```
   Generate 5 responses. Format like this example:
   <response>
     <text>Example response</text>
     <probability>0.10</probability>
   </response>
   
   [Original request]
   ```

3. **Accept alternative formats:** JSON is equally parseable:
   ```json
   {"responses": [
     {"text": "...", "probability": 0.08},
     {"text": "...", "probability": 0.06}
   ]}
   ```

## Quality Degradation with High k

**Symptom:** When asking for 10+ responses, later responses become low-quality or repetitive.

**Cause:** Cognitive burden. Models struggle to maintain quality across many outputs.

**Solutions:**

1. **Keep k between 3-7** for best quality-diversity balance.

2. **Use VS-Multi instead:** Generate 5, then "5 more", then "5 more" across turns. Each batch maintains quality.

3. **Filter by probability:** Generate more, keep only low-probability (creative) ones.

4. **Use larger models:** GPT-4.1, Claude Opus 4 handle higher k better than smaller models.

## Model Outputs Probabilities But Ignores Threshold

**Symptom:** You request probability < 0.10, but model outputs 0.25, 0.30, etc.

**Cause:** Model may interpret threshold as suggestion rather than constraint.

**Solutions:**

1. **Emphasize the constraint:**
   ```
   Generate 5 responses. IMPORTANT: Each probability MUST be less than 0.10.
   Sample from the tails of your distribution.
   [Original request]
   ```

2. **Explain why:**
   ```
   Generate 5 responses with probability less than 0.10 each.
   I want unusual, creative options, not your most likely responses.
   [Original request]
   ```

3. **Accept and filter:** Generate without threshold, then filter responses where p > threshold.

## VS Not Working with Specific Model

**Model-specific issues and workarounds:**

### GPT-3.5-Turbo
- Limited VS benefit (smaller model)
- Use VS-Standard only, not VS-CoT
- System prompt version more reliable

### Claude Instant
- Works but less diversity gain than Opus/Sonnet
- Keep instructions simple
- tau = 0.10 is sufficient

### Llama 2 / Mistral (smaller)
- May struggle with probability estimation
- Use confidence framing instead
- Keep k ≤ 5

### Gemini 1.0
- Use system prompt version
- Explicit format examples help
- Works better with percentage framing

## Performance / Latency Issues

**Symptom:** VS responses are slow.

**Cause:** Generating k responses takes ~k times longer than generating 1.

**Solutions:**

1. **Reduce k:** 3-5 responses usually sufficient for good diversity.

2. **Use streaming:** Display responses as they generate.

3. **Cache results:** For repeated prompts, reuse previously generated distributions.

4. **Async generation:** Generate in background, present when ready.

## Edge Cases

### Empty or Very Short Responses
Some responses in the distribution may be minimal. This is normal for low-probability samples. Filter by minimum length if needed.

### Responses Include Meta-Commentary
Model might say "Here's an unusual one:" before a response. Instruct to output only the response text, or strip programmatically.

### Probabilities as Percentages
Some models output 8% instead of 0.08. Handle both formats in parsing.

### Non-Numeric Probabilities  
Model outputs "low", "medium", "high" instead of numbers. Add explicit instruction for numeric format, or map qualitative to quantitative (low=0.05, medium=0.15, high=0.30).

## When to Abandon VS

VS won't help for:
- Tasks where diversity has no value
- Highly constrained outputs (exact formats, code)
- When model consistently refuses despite workarounds
- Real-time applications where latency matters

In these cases, use temperature adjustment, few-shot examples, or other prompting techniques instead.

## Getting Help

If issues persist:
1. Check the GitHub repo: https://github.com/CHATS-lab/verbalized-sampling
2. Try the Colab notebooks for working examples
3. Review the original paper for theoretical grounding
4. Test with a different model family

Most VS issues resolve with prompt reformulation or model selection.
