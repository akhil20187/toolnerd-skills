# Cloud Architecture Diagram Syntax Reference

Complete syntax reference for Eraser.io cloud architecture diagrams.

## Nodes

Nodes represent cloud services, servers, databases, and other infrastructure components.

### Node Definition
```
NodeName [icon: iconName, color: colorValue]
```

Node names must be unique within a diagram.

### Node Properties

#### icon
Visual identifier for the node. Eraser includes extensive built-in icon libraries for major cloud providers.

**AWS Icons:**
- Compute: `aws-ec2`, `aws-lambda`, `aws-ecs`, `aws-eks`, `aws-batch`
- Storage: `aws-s3`, `aws-ebs`, `aws-efs`, `aws-glacier`
- Database: `aws-rds`, `aws-dynamodb`, `aws-elasticache`, `aws-redshift`, `aws-aurora`
- Networking: `aws-vpc`, `aws-route53`, `aws-cloudfront`, `aws-api-gateway`, `aws-elb`, `aws-alb`
- Integration: `aws-sqs`, `aws-sns`, `aws-kinesis`, `aws-eventbridge`
- Analytics: `aws-athena`, `aws-emr`, `aws-glue`
- Security: `aws-iam`, `aws-kms`, `aws-secrets-manager`, `aws-waf`
- Monitoring: `aws-cloudwatch`, `aws-xray`

**GCP Icons:**
- Compute: `gcp-compute-engine`, `gcp-cloud-functions`, `gcp-cloud-run`, `gcp-gke`
- Storage: `gcp-cloud-storage`, `gcp-persistent-disk`, `gcp-filestore`
- Database: `gcp-cloud-sql`, `gcp-firestore`, `gcp-bigtable`, `gcp-spanner`, `gcp-memorystore`
- Networking: `gcp-cloud-load-balancing`, `gcp-cloud-cdn`, `gcp-cloud-dns`, `gcp-cloud-armor`
- Integration: `gcp-pubsub`, `gcp-cloud-tasks`, `gcp-cloud-scheduler`
- Analytics: `gcp-bigquery`, `gcp-dataflow`, `gcp-dataproc`, `gcp-data-fusion`
- AI/ML: `gcp-ai-platform`, `gcp-vision-api`, `gcp-natural-language-api`
- Monitoring: `gcp-cloud-monitoring`, `gcp-cloud-logging`

**Azure Icons:**
- Compute: `azure-vm`, `azure-functions`, `azure-app-service`, `azure-aks`, `azure-container-instances`
- Storage: `azure-storage`, `azure-blob-storage`, `azure-file-storage`, `azure-disk-storage`
- Database: `azure-sql-database`, `azure-cosmos-db`, `azure-cache-redis`, `azure-database-postgresql`
- Networking: `azure-load-balancer`, `azure-application-gateway`, `azure-cdn`, `azure-dns`, `azure-vpn-gateway`
- Integration: `azure-service-bus`, `azure-event-grid`, `azure-event-hubs`, `azure-logic-apps`
- Analytics: `azure-synapse-analytics`, `azure-databricks`, `azure-data-factory`
- Security: `azure-key-vault`, `azure-active-directory`, `azure-security-center`

**Kubernetes Icons:**
- Core: `k8s-pod`, `k8s-deployment`, `k8s-service`, `k8s-node`, `k8s-namespace`
- Controllers: `k8s-replicaset`, `k8s-statefulset`, `k8s-daemonset`, `k8s-job`, `k8s-cronjob`
- Configuration: `k8s-configmap`, `k8s-secret`, `k8s-pv`, `k8s-pvc`
- Networking: `k8s-ingress`, `k8s-network-policy`, `k8s-endpoint`
- Control Plane: `k8s-control-plane`, `k8s-api`, `k8s-etcd`, `k8s-scheduler`, `k8s-c-m`, `k8s-c-c-m`
- Node Components: `k8s-kubelet`, `k8s-k-proxy`

**General Tech Icons:**
- Servers: `server`, `database`, `cloud`, `monitor`, `cpu`
- Networking: `wifi`, `globe`, `shield`, `lock`
- Data: `hard-drive`, `inbox`, `archive`
- Communication: `mail`, `message-circle`, `phone`
- Tools: `settings`, `tool`, `package`, `code`

#### color
Color identifier or value for the node.

**Common colors:** `blue`, `red`, `green`, `orange`, `purple`, `yellow`, `gray`, `pink`

**Example:**
```
WebServer [icon: aws-ec2, color: blue]
Database [icon: aws-rds, color: green]
Cache [icon: aws-elasticache, color: red]
```

## Groups

Groups are containers that represent logical boundaries like VPCs, subnets, regions, or semantic groupings.

### Group Definition
```
GroupName {
  Node1 [icon: iconName]
  Node2 [icon: iconName]
}
```

Or with comma-separated nodes:
```
GroupName {
  Node1, Node2, Node3
}
```

### Nested Groups

Groups can be nested to represent hierarchical infrastructure:

```
VPC {
  PublicSubnet {
    LoadBalancer [icon: aws-elb]
    WebServer [icon: aws-ec2]
  }
  PrivateSubnet {
    AppServer [icon: aws-ec2]
    Database [icon: aws-rds]
  }
}
```

### Group Properties

Groups support `icon` and `color` properties:

```
Microservices [icon: cloud, color: blue] {
  AuthService [icon: aws-lambda]
  UserService [icon: aws-lambda]
  OrderService [icon: aws-lambda]
}
```

## Connections

Connections represent data flow, communication, or dependencies between components.

### Basic Connection
```
Node1 > Node2
```

### Connection with Multiple Targets
```
LoadBalancer > WebServer1, WebServer2, WebServer3
```

### Bidirectional Flow
For bidirectional connections, use two separate statements:
```
API > Database
Database > API
```

Or simply show the primary direction:
```
API > Database
```

### Connection from Groups
```
LoadBalancer > PrivateSubnet
```

### Connection to Groups
```
PublicSubnet > PrivateSubnet
```

## Direction

Control the layout direction of the diagram:

```
direction: right
```

**Options:**
- `right` - Left to right (default)
- `left` - Right to left
- `up` - Bottom to top
- `down` - Top to bottom

## Styling

### Color Mode
```
colorMode: monochrome
```

**Options:**
- `colored` (default)
- `monochrome`

### Style Mode
```
styleMode: rounded
```

**Options:**
- `plain` (default)
- `rounded`

## Complete Examples

### AWS Serverless Web Application
```
direction: right

// External services
Users [icon: users, color: blue]
CDN [icon: aws-cloudfront, color: orange]

// API Layer
APIGateway [icon: aws-api-gateway, color: green]

// Compute
Lambda {
  AuthFunction [icon: aws-lambda]
  UserFunction [icon: aws-lambda]
  ProductFunction [icon: aws-lambda]
  OrderFunction [icon: aws-lambda]
}

// Data Layer
DynamoDB [icon: aws-dynamodb, color: blue]
S3 [icon: aws-s3, color: orange]
ElastiCache [icon: aws-elasticache, color: red]

// Async Processing
SQS [icon: aws-sqs, color: purple]
SNS [icon: aws-sns, color: pink]

// Analytics
Kinesis [icon: aws-kinesis, color: green]
Redshift [icon: aws-redshift, color: blue]

// Security & Monitoring
WAF [icon: aws-waf, color: red]
CloudWatch [icon: aws-cloudwatch, color: orange]

// Connections
Users > CDN
CDN > WAF
WAF > APIGateway
APIGateway > AuthFunction, UserFunction, ProductFunction, OrderFunction
AuthFunction, UserFunction, ProductFunction, OrderFunction > DynamoDB
OrderFunction > SQS
SQS > SNS
ProductFunction > ElastiCache
AuthFunction, UserFunction, ProductFunction, OrderFunction > S3
APIGateway > Kinesis
Kinesis > Redshift
Lambda > CloudWatch
APIGateway > CloudWatch
```

### GCP Microservices Platform
```
direction: down

// External
Internet [icon: globe, color: blue]
CloudCDN [icon: gcp-cloud-cdn, color: orange]

// Load Balancing
LoadBalancer [icon: gcp-cloud-load-balancing, color: green]
CloudArmor [icon: gcp-cloud-armor, color: red]

// Compute - GKE Cluster
GKECluster [icon: gcp-gke, color: blue] {
  Namespace1 {
    AuthService [icon: k8s-deployment]
    UserService [icon: k8s-deployment]
    PaymentService [icon: k8s-deployment]
  }
  Namespace2 {
    OrderService [icon: k8s-deployment]
    InventoryService [icon: k8s-deployment]
  }
  IngressController [icon: k8s-ingress]
}

// Messaging
PubSub [icon: gcp-pubsub, color: purple]
CloudTasks [icon: gcp-cloud-tasks, color: pink]

// Data Layer
CloudSQL [icon: gcp-cloud-sql, color: blue]
Firestore [icon: gcp-firestore, color: orange]
CloudStorage [icon: gcp-cloud-storage, color: green]
Memorystore [icon: gcp-memorystore, color: red]

// Analytics
BigQuery [icon: gcp-bigquery, color: blue]
Dataflow [icon: gcp-dataflow, color: green]

// Monitoring
CloudMonitoring [icon: gcp-cloud-monitoring, color: orange]
CloudLogging [icon: gcp-cloud-logging, color: gray]

// Connections
Internet > CloudCDN
CloudCDN > CloudArmor
CloudArmor > LoadBalancer
LoadBalancer > IngressController
IngressController > AuthService, UserService, PaymentService, OrderService, InventoryService
AuthService, UserService > CloudSQL
PaymentService, OrderService, InventoryService > Firestore
PaymentService > CloudTasks
OrderService > PubSub
PubSub > InventoryService
AuthService, UserService, PaymentService > Memorystore
OrderService, InventoryService > CloudStorage
PubSub > Dataflow
Dataflow > BigQuery
GKECluster > CloudMonitoring, CloudLogging
```

### Azure Enterprise Architecture
```
// Regional Setup
Region_EastUS [icon: azure, color: blue] {
  
  // Networking
  VNet {
    AppGateway [icon: azure-application-gateway, color: orange]
    
    WebTier {
      WebApp1 [icon: azure-app-service]
      WebApp2 [icon: azure-app-service]
    }
    
    AppTier {
      Functions [icon: azure-functions]
      AKS [icon: azure-aks]
    }
    
    DataTier {
      SQLDatabase [icon: azure-sql-database]
      CosmosDB [icon: azure-cosmos-db]
      RedisCache [icon: azure-cache-redis]
    }
  }
}

// Shared Services
SharedServices [icon: cloud, color: purple] {
  ServiceBus [icon: azure-service-bus]
  EventGrid [icon: azure-event-grid]
  StorageAccount [icon: azure-storage]
  KeyVault [icon: azure-key-vault]
}

// Analytics
Analytics [icon: azure-synapse-analytics, color: green] {
  DataFactory [icon: azure-data-factory]
  Databricks [icon: azure-databricks]
  SynapseAnalytics [icon: azure-synapse-analytics]
}

// Security & Management
Management [icon: shield, color: red] {
  ActiveDirectory [icon: azure-active-directory]
  SecurityCenter [icon: azure-security-center]
  Monitor [icon: monitor]
}

// External
Users [icon: users]
CDN [icon: azure-cdn, color: orange]

// Connections
Users > CDN
CDN > AppGateway
AppGateway > WebApp1, WebApp2
WebApp1, WebApp2 > Functions, AKS
Functions, AKS > SQLDatabase, CosmosDB
Functions, AKS > RedisCache
Functions, AKS > ServiceBus
ServiceBus > EventGrid
Functions, AKS > StorageAccount
StorageAccount > DataFactory
DataFactory > Databricks
Databricks > SynapseAnalytics
Region_EastUS > ActiveDirectory
Region_EastUS > SecurityCenter
Region_EastUS > Monitor
Functions, AKS > KeyVault
```

### Kubernetes Multi-Tier Application
```
// Cloud Provider Integration
CloudProvider [icon: cloud, color: blue] {
  LoadBalancer [icon: k8s-service, label: LoadBalancer Service]
  IngressController [icon: k8s-ingress]
  StorageClass [icon: k8s-pv, label: Persistent Storage]
}

// Kubernetes Cluster
Cluster [icon: k8s-control-plane, color: green] {
  
  // Ingress Namespace
  IngressNamespace [icon: k8s-namespace, label: ingress-nginx] {
    NginxController [icon: k8s-deployment]
  }
  
  // Application Namespace
  AppNamespace [icon: k8s-namespace, label: production] {
    
    // Frontend
    FrontendDeployment [icon: k8s-deployment, label: Frontend]
    FrontendService [icon: k8s-service]
    FrontendHPA [icon: k8s-pod, label: HPA]
    
    // Backend API
    BackendDeployment [icon: k8s-deployment, label: Backend API]
    BackendService [icon: k8s-service]
    BackendConfigMap [icon: k8s-configmap]
    BackendSecrets [icon: k8s-secret]
    
    // Workers
    WorkerStatefulSet [icon: k8s-statefulset, label: Workers]
    WorkerPVC [icon: k8s-pvc]
    
    // Jobs
    CronJob [icon: k8s-cronjob, label: Cleanup Job]
  }
  
  // Monitoring Namespace
  MonitoringNamespace [icon: k8s-namespace, label: monitoring] {
    Prometheus [icon: k8s-deployment]
    Grafana [icon: k8s-deployment]
    PrometheusService [icon: k8s-service]
  }
}

// External Services
ExternalDB [icon: database, color: purple, label: Cloud Database]
ExternalCache [icon: server, color: red, label: Redis]

// Connections
LoadBalancer > NginxController
NginxController > FrontendService, BackendService
FrontendService > FrontendDeployment
BackendService > BackendDeployment
BackendDeployment > BackendConfigMap, BackendSecrets
BackendDeployment > ExternalDB, ExternalCache
WorkerStatefulSet > WorkerPVC
WorkerPVC > StorageClass
BackendDeployment > WorkerStatefulSet
CronJob > BackendService
Cluster > PrometheusService
PrometheusService > Prometheus
Prometheus > Grafana
```

### Hybrid Cloud Architecture
```
direction: down

// On-Premises
OnPrem [icon: server, color: gray, label: On-Premises Data Center] {
  LegacyApps [icon: server, label: Legacy Applications]
  OnPremDB [icon: database, label: Oracle Database]
  DirectoryServices [icon: shield, label: Active Directory]
}

// Connectivity
VPNGateway [icon: aws-vpn-gateway, color: orange]
DirectConnect [icon: server, label: AWS Direct Connect]

// AWS Cloud
AWSCloud [icon: aws, color: orange] {
  
  VPC [icon: aws-vpc] {
    
    PublicSubnet {
      NAT [icon: aws-nat-gateway]
      VPN [icon: aws-vpn-gateway]
    }
    
    PrivateSubnet {
      AppServers [icon: aws-ec2]
      ContainerCluster [icon: aws-ecs]
    }
    
    DataSubnet {
      RDS [icon: aws-rds]
      DocumentDB [icon: aws-dynamodb]
      S3Gateway [icon: aws-s3]
    }
  }
  
  S3 [icon: aws-s3]
  CloudFront [icon: aws-cloudfront]
}

// Integration Services
Integration [icon: cloud, color: blue] {
  DataSync [icon: aws-lambda, label: AWS DataSync]
  APIGateway [icon: aws-api-gateway]
  MessageQueue [icon: aws-sqs]
}

// External Users
Internet [icon: globe, color: blue]

// Connections
OnPrem > VPNGateway, DirectConnect
VPNGateway > VPN
DirectConnect > VPC
Internet > CloudFront
CloudFront > NAT
NAT > AppServers, ContainerCluster
AppServers, ContainerCluster > RDS, DocumentDB
AppServers > S3Gateway
S3Gateway > S3
OnPremDB > DataSync
DataSync > RDS
LegacyApps > APIGateway
APIGateway > ContainerCluster
DirectoryServices > PrivateSubnet
ContainerCluster > MessageQueue
MessageQueue > OnPrem
```

## Best Practices

1. **Use appropriate icons** - Match icons to actual cloud services for clarity
2. **Group logically** - Use groups for VPCs, regions, namespaces, or microservices
3. **Show data flow direction** - Use connections to indicate request/data flow
4. **Apply consistent naming** - Use clear, descriptive names for all components
5. **Leverage colors** - Use colors to categorize layers or environments
6. **Set direction thoughtfully** - Choose direction that best represents your architecture flow
7. **Nest groups appropriately** - Reflect actual infrastructure hierarchy
8. **Keep it focused** - Include essential components, avoid over-complication
9. **Use vendor-specific icons** - Leverage AWS/GCP/Azure icons for authenticity
10. **Document connections** - Show all important integrations and dependencies
