# Manim API Quick Reference for Vedic Mathematics

This reference covers the most commonly used Manim functions for creating Vedic Mathematics educational videos.

## Scene Setup

```python
from manim import *

class MyScene(Scene):
    def construct(self):
        # Your animation code here
        pass
```

## Common Mobjects (Mathematical Objects)

### Text and Mathematical Expressions

```python
# Regular text
text = Text("Hello", font_size=48)
text = Text("Hello", color=BLUE, font_size=36)

# Mathematical text (LaTeX)
formula = MathTex(r"a^2 + b^2 = c^2")
formula = MathTex(r"x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}")

# Multi-line equations
equations = MathTex(
    r"x + y &= 5 \\",
    r"2x - y &= 1"
)

# Text with specific font
text = Text("Numbers", font="Arial", font_size=60)
```

### Numbers and Calculations

```python
# Create number
num = Text("42", font_size=72)

# Integer with automatic formatting
integer = Integer(42)

# Decimal number
decimal = DecimalNumber(3.14159, num_decimal_places=2)
```

### Geometric Objects

```python
# Lines
line = Line(start=LEFT, end=RIGHT, color=YELLOW)
arrow = Arrow(start=LEFT, end=RIGHT)

# Shapes
circle = Circle(radius=1, color=BLUE)
square = Square(side_length=2, color=RED)
rectangle = Rectangle(width=4, height=2)

# Polygons
triangle = Triangle()
polygon = Polygon(point1, point2, point3, ...)
```

## Positioning and Alignment

### Absolute Positioning

```python
# Cardinal directions
obj.to_edge(UP)      # Move to top
obj.to_edge(DOWN)    # Move to bottom
obj.to_edge(LEFT)    # Move to left
obj.to_edge(RIGHT)   # Move to right
obj.to_corner(UL)    # Upper left corner
obj.to_corner(DR)    # Down right corner

# Center
obj.move_to(ORIGIN)  # Move to center
obj.shift(UP * 2)    # Move up by 2 units
obj.shift(RIGHT * 3 + DOWN * 1)
```

### Relative Positioning

```python
# Position relative to another object
obj2.next_to(obj1, RIGHT)       # Place to the right
obj2.next_to(obj1, UP, buff=0.5) # Place above with spacing

# Align with another object
obj2.align_to(obj1, UP)    # Align tops
obj2.align_to(obj1, LEFT)  # Align left edges

# Position around the center
obj.move_to(reference_obj.get_center())
```

### Useful Coordinate Methods

```python
obj.get_center()    # Get center coordinates
obj.get_top()       # Get top point
obj.get_bottom()    # Get bottom point
obj.get_left()      # Get leftmost point
obj.get_right()     # Get rightmost point
```

## Animations

### Basic Animations

```python
# Write text/formula character by character
self.play(Write(text))

# Fade in/out
self.play(FadeIn(obj))
self.play(FadeOut(obj))

# Create (for lines, shapes)
self.play(Create(line))

# Transform one object into another
self.play(Transform(obj1, obj2))

# Replace one object with another
self.play(ReplacementTransform(obj1, obj2))
```

### Emphasis and Highlighting

```python
# Indicate (pulse effect)
self.play(Indicate(obj, color=YELLOW, scale_factor=1.2))

# Circumscribe (draw shape around)
self.play(Circumscribe(obj, color=YELLOW, shape=Rectangle))

# Flash
self.play(Flash(obj))

# Wiggle
self.play(Wiggle(obj))

# Focus on specific part
self.play(FocusOn(obj))
```

### Groups and Sequences

```python
# Group multiple objects
group = VGroup(obj1, obj2, obj3)
self.play(Write(group))  # Animates all together

# Animate sequentially
self.play(
    Write(text1),
    Write(text2),
    lag_ratio=1  # Second starts after first finishes
)

# Animate multiple at once
self.play(
    FadeIn(obj1),
    FadeOut(obj2),
    Transform(obj3, obj4)
)
```

### Animation Timing

```python
# Wait between animations
self.wait()       # Wait 1 second (default)
self.wait(2)      # Wait 2 seconds
self.wait(0.5)    # Wait 0.5 seconds

# Animation speed
self.play(Write(text), run_time=2)  # Take 2 seconds
```

## Colors

### Predefined Colors

```python
# Basic colors
WHITE, BLACK, GRAY
RED, GREEN, BLUE
YELLOW, ORANGE, PURPLE
PINK, TEAL, MAROON

# Light versions
LIGHT_GRAY, LIGHT_PINK
LIGHT_BROWN, LIGHT_GREEN

# Dark versions
DARK_BLUE, DARK_BROWN, DARK_GRAY

# Specific shades
RED_A, RED_B, RED_C, RED_D, RED_E
BLUE_A, BLUE_B, BLUE_C, BLUE_D, BLUE_E
```

### Custom Colors

```python
# RGB
custom_color = rgb_to_color([1, 0.5, 0])  # RGB values 0-1

# Hex
custom_color = "#FF5733"
```

## Layout Patterns for Vedic Math

### Standard Calculation Layout

```python
# Title at top
title = Text("Method Name", font_size=48).to_edge(UP)

# Numbers in middle-upper area
num1 = Text("23", font_size=72).shift(UP * 1 + LEFT * 2)
num2 = Text("14", font_size=72).shift(UP * 1 + RIGHT * 2)
operator = Text("×", font_size=60).shift(UP * 1)

# Working area in center
# (calculations, lines, etc.)

# Step explanation at bottom
step = Text("Step 1: ...", font_size=36).to_edge(DOWN)
```

### Side-by-Side Comparison

```python
# Left side
left_label = Text("Traditional").shift(UP * 3 + LEFT * 3)
left_calc = VGroup(...)  # Calculation on left

# Right side  
right_label = Text("Vedic Method").shift(UP * 3 + RIGHT * 3)
right_calc = VGroup(...)  # Calculation on right

# Divider
divider = Line(UP * 3, DOWN * 3, color=GRAY)
```

## Common Vedic Math Animation Patterns

### Crosswise Multiplication Lines

```python
# Connect digits with crossing lines
n1_digits = [Text(d) for d in "23"]
n2_digits = [Text(d) for d in "14"]

# Cross lines
line1 = Line(
    n1_digits[0].get_center(), 
    n2_digits[1].get_center(),
    color=YELLOW,
    stroke_width=3
)
line2 = Line(
    n1_digits[1].get_center(),
    n2_digits[0].get_center(), 
    color=YELLOW,
    stroke_width=3
)

self.play(Create(line1), Create(line2))
```

### Highlighting Deviations

```python
# Show deviation with colored text
deviation_text = Text(f"{dev:+d}", color=RED)  # +/- sign
deviation_text.next_to(number, RIGHT)

# Draw brace to show deviation
brace = Brace(number_group, UP)
deviation_label = brace.get_text(f"Deviation: {dev}")
```

### Step-by-Step Replacement

```python
# Show calculation evolving
calc1 = MathTex("2 \\times 3")
self.play(Write(calc1))
self.wait()

calc2 = MathTex("= 6")
calc2.next_to(calc1, RIGHT)
self.play(Write(calc2))
self.wait()

# Or replace entirely
calc_combined = MathTex("2 \\times 3 = 6")
self.play(Transform(VGroup(calc1, calc2), calc_combined))
```

### Grid Layout for Digits

```python
# Create a grid of digits
digits = VGroup()
for i, digit in enumerate("1234"):
    d = Text(digit, font_size=50)
    d.shift(RIGHT * i * 0.8)
    digits.add(d)

# Center the group
digits.move_to(ORIGIN)
```

## Performance Tips

1. **Limit concurrent animations**: Too many at once can be overwhelming
2. **Use VGroup**: Efficiently manage related objects
3. **Reuse objects**: Transform instead of creating new when possible
4. **Clear screen**: Use `self.remove()` or `FadeOut()` to declutter
5. **Appropriate run_time**: 0.5-1s for quick, 2-3s for complex animations

## Rendering Commands

```bash
# Development quality (fast)
manim -ql script.py SceneName

# Medium quality
manim -qm script.py SceneName

# High quality (1080p)
manim -qh script.py SceneName

# Production quality (4K)
manim -qk script.py SceneName

# Save last frame as image
manim -sql script.py SceneName

# Show preview immediately
manim -p script.py SceneName
```

## Useful Shortcuts

```python
# Quick colors for steps
STEP_COLORS = [YELLOW, GREEN, BLUE, ORANGE, PURPLE]

# Center text horizontally, specific vertical position
text.move_to(UP * 2)  # Keeps horizontal center

# Quick grid creation
VGroup(*[obj for obj in objects]).arrange(RIGHT, buff=0.5)
VGroup(*[obj for obj in objects]).arrange(DOWN, buff=0.3)
```
