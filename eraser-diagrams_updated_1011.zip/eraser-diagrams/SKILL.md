---
name: eraser-diagrams
description: Generate professional diagrams using Eraser.io's diagram-as-code syntax. Use this skill when users request flowcharts, entity relationship diagrams (ERDs), cloud architecture diagrams, sequence diagrams, or BPMN/swimlane diagrams. Trigger on requests like "create a flowchart", "draw an ERD", "design system architecture", "show me a sequence diagram", or "make a BPMN diagram". This skill provides syntax knowledge for creating beautiful, auto-formatted technical diagrams using text-based DSL.
---

# Eraser Diagrams

## Overview

This skill enables creation of professional technical diagrams using Eraser.io's diagram-as-code syntax. The diagram-as-code approach allows rapid creation of beautiful diagrams without GUI manipulation, making them ideal for technical documentation, system design, process mapping, and data modeling.

## Supported Diagram Types

This skill supports five diagram types:

1. **Flow Charts** - Process flows, user flows, logic flows
2. **Entity Relationship Diagrams (ERD)** - Database schemas and data models
3. **Cloud Architecture Diagrams** - Infrastructure and system architecture
4. **Sequence Diagrams** - System interactions and message flows
5. **BPMN Diagrams** - Business processes with swimlanes

## Quick Start

When creating any Eraser.io diagram:

1. Identify the diagram type needed based on user request
2. Review the specific syntax section below for that diagram type
3. Generate diagram code using proper Eraser.io syntax
4. Present the code in a code block with language identifier `eraser`
5. Include brief explanation of key diagram elements

**Output Format:**
```eraser
// Diagram code here
```

## 1. Flow Charts

Flow charts visualize process flows, user flows, and logic flows using nodes, groups, and connections.

### Core Syntax

**Nodes** (basic building blocks):
```eraser
NodeName [shape: oval, icon: user, color: blue]
```

**Groups** (containers for nodes):
```eraser
GroupName {
  Node1, Node2, Node3
}
```

**Connections** (relationships):
```eraser
Node1 > Node2: Connection label
Node1 < Node2: Reverse connection
```

**Direction Control:**
```eraser
direction: right  // Options: right, left, up, down
```

### Node Shapes

Available shapes: `rectangle` (default), `cylinder`, `diamond`, `document`, `ellipse`, `hexagon`, `oval`, `parallelogram`, `star`, `trapezoid`, `triangle`

### Node Properties

- `shape` - Visual shape of the node
- `icon` - Icon identifier from Eraser's library
- `color` - Color value (blue, red, green, etc.)
- `label` - Display text (different from node name)

### Example

```eraser
// User authentication flow
Start [shape: oval]
CheckCredentials [shape: diamond, label: Valid Credentials?]
LoginSuccess [shape: rectangle, color: green]
LoginFailed [shape: rectangle, color: red]
End [shape: oval]

AuthenticationSystem {
  ValidateUser
  GenerateToken
  LogActivity
}

Start > CheckCredentials
CheckCredentials > LoginSuccess: Yes
CheckCredentials > LoginFailed: No
LoginSuccess > GenerateToken
GenerateToken > LogActivity > End
LoginFailed > End
```

## 2. Entity Relationship Diagrams (ERD)

ERDs visualize database schemas with entities, attributes, and relationships.

### Core Syntax

**Entities** (database tables):
```eraser
tableName [icon: user, color: blue] {
  id string pk
  name string
  email string
}
```

**Attributes** (table columns):
- Format: `attributeName type metadata`
- Types: `string`, `int`, `boolean`, `timestamp`, etc.
- Metadata: `pk` (primary key), `fk` (foreign key), `unique`, `null`

**Relationships**:
```eraser
// Inside entity definition
users {
  teamId < teams.id
}

// Or as separate statements
users.teamId > teams.id
```

### Relationship Cardinality

- `>` - One-to-many (entity has many)
- `<` - Many-to-one (entity belongs to)
- `<>` - Many-to-many

### Example

```eraser
users [icon: user, color: blue] {
  id string pk
  email string unique
  displayName string
  createdAt timestamp
  teamId < teams.id
}

teams [icon: users, color: blue] {
  id string pk
  name string
  ownerId > users.id
}

projects [icon: folder, color: green] {
  id string pk
  title string
  teamId > teams.id
  createdBy > users.id
}

tasks [icon: check-square, color: orange] {
  id string pk
  title string
  status string
  projectId > projects.id
  assigneeId > users.id
}
```

## 3. Cloud Architecture Diagrams

Architecture diagrams visualize cloud infrastructure with nodes, groups, and connections.

### Core Syntax

**Nodes** (cloud services):
```eraser
ServiceName [icon: aws-ec2, color: orange]
```

**Groups** (logical containers):
```eraser
VPCName {
  SubnetName {
    Service1 [icon: aws-ec2]
    Service2 [icon: aws-rds]
  }
}
```

**Connections** (data flow):
```eraser
Service1 > Service2
Service1 > Service2, Service3  // Multiple targets
```

### Built-in Icons

Extensive icon library includes:
- **AWS**: `aws-ec2`, `aws-lambda`, `aws-s3`, `aws-rds`, `aws-api-gateway`, `aws-dynamodb`, `aws-cloudfront`, `aws-route53`, etc.
- **GCP**: `gcp-compute-engine`, `gcp-cloud-storage`, `gcp-bigquery`, `gcp-pubsub`, `gcp-cloud-functions`, etc.
- **Azure**: `azure-vm`, `azure-storage`, `azure-functions`, `azure-sql-database`, etc.
- **Kubernetes**: `k8s-pod`, `k8s-service`, `k8s-deployment`, `k8s-node`, `k8s-control-plane`, etc.
- **General**: `server`, `database`, `monitor`, `cloud`, `settings`, etc.

### Example

```eraser
// E-commerce platform architecture
direction: right

CDN [icon: aws-cloudfront]
APIGateway [icon: aws-api-gateway]
LoadBalancer [icon: aws-elb]

VPC {
  PublicSubnet {
    WebServer1 [icon: aws-ec2]
    WebServer2 [icon: aws-ec2]
  }
  
  PrivateSubnet {
    AppServer1 [icon: aws-ec2]
    AppServer2 [icon: aws-ec2]
    Cache [icon: aws-elasticache]
  }
  
  DatabaseSubnet {
    PrimaryDB [icon: aws-rds]
    ReplicaDB [icon: aws-rds]
  }
}

Storage [icon: aws-s3]
Queue [icon: aws-sqs]
Analytics [icon: aws-redshift]

// Connections
CDN > APIGateway
APIGateway > LoadBalancer
LoadBalancer > WebServer1, WebServer2
WebServer1, WebServer2 > AppServer1, AppServer2
AppServer1, AppServer2 > Cache
AppServer1, AppServer2 > PrimaryDB
PrimaryDB > ReplicaDB
AppServer1, AppServer2 > Queue
Storage > Analytics
Queue > Analytics
```

## 4. Sequence Diagrams

Sequence diagrams visualize system interactions with actors, messages, and control flows.

### Core Syntax

**Messages** (interactions):
```eraser
Actor1 [icon: monitor] > Actor2 [icon: server]: Message text
```

**Message Format:**
- Column names separated by `>`
- Message text after `:`
- Columns auto-created on first use

**Column Properties:**
- `icon` - Visual identifier
- `color` - Color value
- `label` - Display name (different from internal name)

### Control Flow Blocks

**Alternative paths:**
```eraser
alt [label: condition] {
  Server > Client: Success response
} else [label: otherwise] {
  Server > Client: Error response
}
```

**Parallel execution:**
```eraser
par [label: parallel tasks] {
  Server > Service1: Task 1
} and [label: concurrent] {
  Server > Service2: Task 2
}
```

**Other blocks:**
- `loop [label: condition]` - Repeated execution
- `opt [label: condition]` - Optional execution
- `critical [label: section]` - Critical section

### Activations

Show when an actor is actively processing:
```eraser
activate Server
Server > Database: Query
Database > Server: Results
deactivate Server
```

### Example

```eraser
// User authentication flow
Client [icon: monitor, color: blue] > API [icon: server, color: green]: POST /login
activate API

API > AuthService [icon: shield, color: orange]: Validate credentials
activate AuthService

AuthService > Database [icon: database]: Query user
Database > AuthService: User data

alt [label: credentials valid] {
  AuthService > TokenService [icon: key]: Generate token
  TokenService > AuthService: JWT token
  AuthService > API: Authentication successful
  API > Client: 200 OK with token
} else [label: credentials invalid] {
  AuthService > API: Authentication failed
  API > Client: 401 Unauthorized
}

deactivate AuthService
deactivate API

Client > API: GET /profile with token
activate API
API > TokenService: Verify token
TokenService > API: Token valid
API > Database: Fetch profile
Database > API: Profile data
API > Client: 200 OK with profile
deactivate API
```

## 5. BPMN Diagrams (Swimlane Diagrams)

BPMN diagrams visualize business processes with pools, lanes, and flow objects.

### Core Syntax

**Pools** (organizations/departments):
```eraser
OrganizationName {
  // Flow objects and lanes
}
```

**Lanes** (roles within pools):
```eraser
Department {
  Manager {
    // Flow objects
  }
  Employee {
    // Flow objects
  }
}
```

**Flow Objects**:
```eraser
TaskName [type: activity]
EventName [type: event]
DecisionName [type: gateway]
```

### Flow Object Types

- `activity` (default) - Tasks or actions
- `event` - Start/end points, milestones
- `gateway` - Decision points, branching

### Flow Object Properties

- `type` - Object type (activity/event/gateway)
- `icon` - Visual identifier
- `color` - Color value
- `label` - Display text

**⚠️ CRITICAL - Label Restrictions:**
Labels cannot contain these special characters: `{` `}` `[` `]` `<` `>` `:` `,` `/`

Use alternatives:
- `()` instead of `[]` → `Complete? (Unknown)` ✅ not `Complete? [Unknown]` ❌
- `greater than` instead of `>` → `Amount greater than 100K?` ✅ not `Amount > 100K?` ❌
- `or` or `-` instead of `/` → `Approve or Reject?` ✅ not `Approve/Reject?` ❌

### Connections

```eraser
Task1 > Task2
Task1 > Task2, Task3  // Multiple paths
```

### Example

```eraser
// Order fulfillment process
Customer {
  BrowseProducts [type: activity]
  AddToCart [type: activity]
  Checkout [type: activity]
  PaymentSubmitted [type: event]
}

OrderManagement {
  ValidateOrder [type: activity]
  CheckInventory [type: gateway, label: In Stock?]
  ProcessPayment [type: activity]
  OrderConfirmed [type: event]
}

Warehouse {
  Manager {
    ReviewOrder [type: activity]
    ApproveShipment [type: gateway, label: Approved?]
  }
  
  Worker {
    PickItems [type: activity]
    PackOrder [type: activity]
    ShipOrder [type: activity]
    OrderShipped [type: event]
  }
}

// Process flow
BrowseProducts > AddToCart > Checkout > PaymentSubmitted
PaymentSubmitted > ValidateOrder > CheckInventory
CheckInventory > ProcessPayment: Yes
CheckInventory > OrderConfirmed: No - Notify Customer
ProcessPayment > OrderConfirmed
OrderConfirmed > ReviewOrder > ApproveShipment
ApproveShipment > PickItems: Yes
ApproveShipment > OrderConfirmed: No - Cancel
PickItems > PackOrder > ShipOrder > OrderShipped
```

## Common Styling Options

All diagram types support styling at the diagram level:

```eraser
// Direction (where applicable)
direction: right  // Options: right, left, up, down

// Color mode
colorMode: monochrome  // Options: monochrome, colored

// Style mode
styleMode: rounded  // Options: plain, rounded

// Typeface
typeface: arial  // Various font options available
```

## Special Characters

**In Names (flow objects, pools, lanes):**
To use reserved characters in names, wrap the entire name in double quotes:

```eraser
Customer {
  "Place / Cancel Order" [type: activity]
  "Check Status?" [type: gateway]
}
```

**In Labels (property values):**
⚠️ **IMPORTANT:** Labels cannot contain these characters even with quotes: `{` `}` `[` `]` `<` `>` `:` `,` `/`

Use alternative characters:
```eraser
// ✅ CORRECT
IsComplete [type: gateway, label: Complete? (Unknown)]
CheckAmount [type: gateway, label: Amount greater than 100K?]

// ❌ WRONG
IsComplete [type: gateway, label: Complete? [Unknown]]
CheckAmount [type: gateway, label: Amount > 100K?]
```

Reserved characters include: `{`, `}`, `[`, `]`, `>`, `<`, `:`, `,`, `/`

## Best Practices

1. **Use descriptive names** - Make node/entity names clear and meaningful
2. **Apply consistent naming** - Use camelCase or snake_case consistently
3. **Leverage icons** - Icons make diagrams more intuitive and professional
4. **Group logically** - Use groups to organize related components
5. **Add labels for clarity** - Use connection labels to explain relationships
6. **Set direction appropriately** - Match flow direction to natural reading order
7. **Use colors strategically** - Highlight important elements or categorize components
8. **Keep it simple** - Start with essential elements, add complexity as needed

## Workflow Decision Tree

When user requests a diagram:

1. **Identify diagram type** from user request keywords:
   - "flowchart", "process flow", "workflow" → Flow Chart
   - "ERD", "database", "data model", "schema" → ERD
   - "architecture", "infrastructure", "cloud", "system design" → Architecture
   - "sequence", "interaction", "message flow", "API flow" → Sequence
   - "BPMN", "swimlane", "business process", "lanes" → BPMN

2. **Review syntax** for the identified diagram type in the sections above

3. **Generate diagram code** using proper Eraser.io syntax

4. **Present formatted output** in eraser code block

5. **Explain key elements** briefly to help user understand the diagram

## References

For comprehensive syntax details, examples, and edge cases, refer to:
- `references/flowchart_syntax.md` - Complete flow chart syntax reference
- `references/erd_syntax.md` - Complete ERD syntax reference  
- `references/architecture_syntax.md` - Complete architecture diagram syntax
- `references/sequence_syntax.md` - Complete sequence diagram syntax
- `references/bpmn_syntax.md` - Complete BPMN syntax reference
- `references/icon_library.md` - Complete icon catalog with categories
