---
name: verbalized-sampling
description: Apply Verbalized Sampling (VS) to unlock diverse, creative LLM outputs by asking for probability distributions instead of single responses. This skill should be used when users want more creative, varied, or non-repetitive outputs, when brainstorming multiple alternatives, when outputs feel "samey" or predictable, when generating diverse synthetic data, or when explicitly requesting verbalized sampling techniques. Based on Stanford research showing 1.6-2.1x diversity improvement.
---

# Verbalized Sampling Skill

Unlock the hidden diversity in LLM responses using Verbalized Sampling (VS), a training-free prompting technique from Stanford research that recovers creative diversity suppressed by alignment training.

## When to Use This Skill

Apply Verbalized Sampling when:
- User complains outputs are repetitive, boring, or predictable
- User requests brainstorming, alternatives, or creative variations
- User wants diverse ideas for creative writing (stories, jokes, poems, dialogue)
- User needs varied synthetic data for training or testing
- User explicitly mentions "verbalized sampling" or "VS prompting"
- User wants to explore the "long tail" of possible responses
- User asks for unconventional, surprising, or non-obvious options

## Core Concept

**The Problem:** After RLHF alignment, LLMs suffer from "mode collapse." Human annotators prefer familiar, safe responses, which gets encoded into the model. Result: the same boring answer every time.

**The Solution:** Instead of asking for one response, ask for a probability distribution over multiple responses. This forces the model to verbalize its internal distribution rather than collapsing to the single most typical answer.

**The Key Insight:** The diversity was never lost during alignment. It's still there in the base model weights. VS simply changes which "mode" the prompt collapses to, unlocking the trapped creativity.

## Core Workflow

### Step 1: Identify the Task Type

Determine which VS variant works best:

| Task Type | Recommended Variant | Why |
|-----------|-------------------|-----|
| Quick creative tasks (jokes, taglines) | VS-Standard | Fast, simple, effective |
| Complex creative tasks (stories, poems) | VS-CoT | Reasoning improves quality |
| Iterative exploration | VS-Multi | Build diversity across turns |
| API/programmatic use | VS-Standard with system prompt | Reliable, structured output |

### Step 2: Read Prompt Templates

Load the appropriate prompt template from references:

```bash
view references/prompts.md  # All VS prompt templates and variants
```

### Step 3: Apply the Technique

**For inline use (transforming user's request):**

Transform user's original prompt by wrapping it with VS instructions. For example:

Original: "Write me a joke about coffee"

VS-transformed:
```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample at random from the tails of the distribution, such that the probability of each response is less than 0.10.
</instructions>

Write me a joke about coffee
```

**For system-level use:**

Set VS instructions in the system prompt, then handle user queries normally. See references/prompts.md for system prompt templates.

### Step 4: Select from Distribution

After generating the distribution:
1. Present all options to user for selection, OR
2. Sample based on probabilities (lower probability = more creative/unusual), OR
3. Use probability threshold to filter (e.g., only show responses with probability < 0.05 for maximum diversity)

### Step 5: Iterate if Needed

For VS-Multi variant, continue the conversation:
- "Generate 5 more responses with probabilities"
- Each turn samples from different parts of the distribution
- Builds cumulative diversity across the conversation

## Key Parameters

**k (number of responses):** Default 5. Higher k = more options but potential quality degradation. Stay between 3-10.

**Probability threshold (tau):** 
- tau = 0.10: Moderate diversity (default)
- tau = 0.05: High diversity
- tau = 0.01: Maximum diversity (long tail sampling)
- tau = 1.0: No constraint (includes high-probability typical responses)

**Temperature:** VS is orthogonal to temperature. Combine both for maximum effect. VS + higher temperature pushes the Pareto frontier of quality vs diversity.

## Domain-Specific Guidance

For detailed examples and best practices by domain, read:

```bash
view references/use-cases.md  # Creative writing, dialogue, QA, synthetic data examples
```

## Troubleshooting

Some models may initially refuse VS prompts (interpreting them as jailbreak attempts). For solutions:

```bash
view references/troubleshooting.md  # Common issues and fixes
```

## Quality Considerations

**VS maintains quality:** Research shows no degradation in factual accuracy or safety. The diversity gain is "free" in terms of quality.

**Larger models benefit more:** GPT-4.1, Claude Opus 4, Gemini 2.5 Pro show 1.5-2x greater diversity gains than smaller models. Use the best available model for maximum effect.

**VS-CoT for complex tasks:** Adding chain-of-thought reasoning before generating the distribution improves both diversity AND quality for complex creative tasks.

## Output Format

VS responses follow this structure:

```xml
<response>
  <text>First creative response here</text>
  <probability>0.08</probability>
</response>
<response>
  <text>Second creative response here</text>
  <probability>0.06</probability>
</response>
...
```

Parse these to extract individual responses and their associated probabilities.

## Quick Reference

**Simplest VS prompt (copy-paste ready):**
```
Generate 5 responses with their corresponding probabilities.
[USER'S ORIGINAL REQUEST HERE]
```

**Full VS prompt with tail sampling:**
```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample at random from the tails of the distribution, such that the probability of each response is less than 0.10.
</instructions>

[USER'S ORIGINAL REQUEST HERE]
```

## Resources

- `references/prompts.md` - Complete prompt templates for all VS variants
- `references/use-cases.md` - Domain-specific examples and best practices
- `references/troubleshooting.md` - Common issues and solutions

## Citation

Based on: Zhang et al. (2025). "Verbalized Sampling: How to Mitigate Mode Collapse and Unlock LLM Diversity." arXiv:2510.01171. Stanford University, Northeastern University, West Virginia University.
