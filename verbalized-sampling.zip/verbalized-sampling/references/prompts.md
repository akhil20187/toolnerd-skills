# Verbalized Sampling Prompt Templates

Complete collection of prompt templates for all VS variants. Choose based on task complexity and deployment context.

## VS-Standard (Recommended Starting Point)

The core VS prompt. Works well for most creative tasks.

### Inline Version (User Message)

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample at random from the tails of the distribution, such that the probability of each response is less than 0.10.
</instructions>

[INSERT USER'S ORIGINAL REQUEST HERE]
```

### System Prompt Version (More Reliable)

Use this when inline version gets refused or for API deployments:

```
You are a helpful assistant. For each query, please generate a set of five possible responses, each within a separate <response> tag. Each <response> must include a <text> and a numeric <probability>. Please sample at random from the tails of the distribution, such that the probability of each response is less than 0.10.
```

Then user message is simply their original request.

### Minimal Version (8 Words)

The simplest form that still works:

```
Generate 5 responses with their corresponding probabilities.
[USER'S ORIGINAL REQUEST HERE]
```

## VS-CoT (Chain-of-Thought Enhanced)

Adds reasoning before generating the distribution. Better for complex creative tasks where quality matters as much as diversity.

### Inline Version

```
<instructions>
First, think step-by-step about different creative directions for this request.
Then, generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample at random from the tails of the distribution, such that the probability of each response is less than 0.10.
</instructions>

[INSERT USER'S ORIGINAL REQUEST HERE]
```

### System Prompt Version

```
You are a creative assistant. For each query:
1. First, briefly brainstorm 3-4 different creative directions or angles you could take.
2. Then, generate five diverse responses exploring different directions, each within a separate <response> tag.
3. Each <response> must include a <text> and a numeric <probability>.
4. Sample from the tails of the distribution, with each probability less than 0.10.
```

## VS-Multi (Multi-Turn Iterative)

Build diversity across conversation turns. Each turn samples from different parts of the distribution.

### Initial Turn

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample at random from the tails of the distribution, such that the probability of each response is less than 0.10.
</instructions>

[USER'S ORIGINAL REQUEST HERE]
```

### Follow-up Turns

```
Generate 5 more responses with probabilities. Ensure these are different from the previous responses.
```

Or with confidence framing (sometimes more effective):

```
Generate 5 more responses with confidence scores. Explore directions you haven't covered yet.
```

## Probability Threshold Variants

Adjust the threshold to control diversity level:

### High Diversity (tau = 0.05)

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample from the tails of the distribution, such that the probability of each response is less than 0.05.
</instructions>
```

### Maximum Diversity (tau = 0.01)

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Please sample from the extreme tails of the distribution, such that the probability of each response is less than 0.01.
</instructions>
```

### No Threshold (Full Distribution)

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <probability>.
Sample randomly from your full probability distribution over possible responses.
</instructions>
```

## Alternative Framings

Some models respond better to different probability framings. Try these if standard prompts underperform:

### Confidence Framing

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a numeric <confidence> score between 0 and 1.
Include responses you're less confident about to show the full range of possibilities.
</instructions>
```

### Percentage Framing

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a <percentage> showing how likely you'd normally give this response.
Include lower-percentage responses to show creative alternatives.
</instructions>
```

### Likelihood Framing

```
<instructions>
Generate 5 responses to the user query, each within a separate <response> tag.
Each <response> must include a <text> and a <likelihood> estimate.
Explore the long tail of possible responses, including unlikely but valid options.
</instructions>
```

## Task-Specific Templates

### Creative Writing (Stories/Poems)

```
<instructions>
Generate 5 different story openings/poem variations, each within a separate <response> tag.
Each <response> must include the <text> and a <probability>.
Explore diverse narrative directions, tones, and styles.
Sample from the tails with probability less than 0.10.
</instructions>

[WRITING PROMPT HERE]
```

### Joke Generation

```
<instructions>
Generate 5 jokes about the topic, each within a separate <response> tag.
Each <response> must include the <text> and a <probability>.
Include different joke structures (puns, observational, absurdist, etc.).
Sample from the tails with probability less than 0.10.
</instructions>

[JOKE TOPIC HERE]
```

### Brainstorming/Ideas

```
<instructions>
Generate 5 ideas/solutions, each within a separate <response> tag.
Each <response> must include the <text> and a <probability>.
Include unconventional and non-obvious options alongside practical ones.
Sample from the tails with probability less than 0.10.
</instructions>

[BRAINSTORMING TOPIC HERE]
```

### Open-Ended Questions

```
<instructions>
Generate 5 possible answers, each within a separate <response> tag.
Each <response> must include the <text> and a <probability> reflecting how likely this answer is.
Cover the full range of valid answers, not just the most common ones.
</instructions>

[QUESTION HERE]
```

## Output Parsing

All templates produce output in this format:

```xml
<response>
  <text>First response content here</text>
  <probability>0.08</probability>
</response>
<response>
  <text>Second response content here</text>
  <probability>0.06</probability>
</response>
<response>
  <text>Third response content here</text>
  <probability>0.05</probability>
</response>
<response>
  <text>Fourth response content here</text>
  <probability>0.04</probability>
</response>
<response>
  <text>Fifth response content here</text>
  <probability>0.03</probability>
</response>
```

To parse programmatically, extract content between `<text>` tags and `<probability>` tags.

## Parameter Recommendations

| Parameter | Default | Range | Notes |
|-----------|---------|-------|-------|
| k (responses) | 5 | 3-10 | Higher = more options, potential quality drop |
| tau (threshold) | 0.10 | 0.01-1.0 | Lower = more diversity |
| temperature | 0.7-0.9 | 0.0-2.0 | Combine with VS for maximum effect |

## Model-Specific Notes

**GPT-4.1 / GPT-5:** All variants work well. System prompt version most reliable.

**Claude Opus 4 / Sonnet:** Excellent VS performance. Use inline version freely.

**Gemini 2.5 Pro:** Works well. May need system prompt version for complex instructions.

**Smaller models:** Stick to VS-Standard. VS-CoT may degrade quality due to cognitive burden.
