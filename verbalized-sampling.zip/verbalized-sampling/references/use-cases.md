# Verbalized Sampling Use Cases

Domain-specific guidance, examples, and best practices for applying VS effectively.

## Creative Writing

### Story Generation

**Problem:** Direct prompting produces formulaic narratives. "Write a story starting with 'Without a goodbye'" always yields breakup scenes or departure narratives.

**VS Solution:** Generates diverse narrative directions including cosmic events, silent emails, music stopping mid-dance, career changes, friendship endings.

**Best Practices:**
- Use VS-CoT for longer stories (the reasoning phase improves narrative coherence)
- Set tau = 0.05 for maximum creative diversity
- Use VS-Multi to explore multiple story directions before committing

**Example Transform:**

Before:
```
Write a short story starting with "Without a goodbye"
```

After:
```
<instructions>
Generate 5 story openings, each within a separate <response> tag.
Each <response> must include a <text> and a <probability>.
Explore diverse genres, tones, and narrative directions.
Sample from the tails with probability less than 0.10.
</instructions>

Write a short story starting with "Without a goodbye"
```

**Expected Output Diversity:**
- Romantic departure (typical)
- Cosmic event ending communication
- Character death mid-sentence
- Silent email resignation
- Music stopping at a dance
- Friendship fading without confrontation

### Poetry/Poem Continuation

**Problem:** AI poetry tends toward predictable rhyme schemes, common metaphors, and safe emotional territory.

**VS Solution:** Unlocks experimental forms, unusual metaphors, varied emotional registers.

**Best Practices:**
- VS-CoT works particularly well (reasoning about poetic directions)
- Combine with style-specific instructions for genre diversity
- Use VS-Multi to iterate on promising directions

### Joke Writing

**Problem:** The coffee joke problem. Ask for a coffee joke 5 times, get "It got mugged!" every time.

**VS Solution:** Surfaces puns, observational humor, absurdist jokes, wordplay, anti-humor.

**Example:**

Before (5 attempts):
```
Why did the coffee file a police report? It got mugged! (x5)
```

After (VS):
```
1. Espresso may not solve all your problems, but it's a good shot. (0.12)
2. Error 404: Coffee not found. Please restart human. (0.07)
3. Why did the latte go to therapy? It had too much foam to deal with. (0.15)
4. Cold brew is just coffee that took a gap year to find itself. (0.07)
5. Coffee: because anger management is too expensive. (0.06)
```

## Dialogue Simulation

**Problem:** LLM-simulated humans are unrealistically agreeable. In persuasion tasks, they always donate, always agree, never show realistic resistance.

**VS Solution:** Surfaces human-like behaviors including hesitation, resistance, changing one's mind, partial agreement.

**Application:** Social simulation, user testing, training data generation.

**Best Practices:**
- Use VS at each dialogue turn to sample realistic responses
- Model-decided random sampling OR probability-weighted sampling both work
- Lower thresholds produce more resistant/varied behaviors

**Example (Donation Persuasion):**

Direct prompting: Simulated person always agrees to donate $10.

VS prompting: Distribution of behaviors:
- Immediate agreement (0.15)
- Polite refusal (0.12)
- Hesitation then small donation (0.18)
- Initial refusal then reconsideration (0.08)
- Counter-questions about charity legitimacy (0.05)

The resulting donation distribution matches human data much more closely.

## Open-Ended QA

**Problem:** "Name a US state" returns California or Texas 90% of the time. The model collapses to high-frequency answers.

**VS Solution:** Generates a distribution matching real-world frequency (including Vermont, Wyoming, Delaware).

**Best Practices:**
- Use for any question with multiple valid answers
- Compare verbalized probabilities to real-world distributions
- Good for survey simulation, enumeration tasks, coverage testing

**Example:**

Question: "Name a country that starts with 'M'"

Direct (10 attempts): Mexico (7), Malaysia (2), Morocco (1)

VS: 
- Mexico (0.18)
- Malaysia (0.12)
- Morocco (0.09)
- Mongolia (0.07)
- Madagascar (0.06)
- Malta (0.04)
- Mauritius (0.03)
- Moldova (0.03)
- Myanmar (0.02)
- Monaco (0.02)

## Synthetic Data Generation

**Problem:** LLM-generated training data lacks diversity. Fine-tuning on this data amplifies mode collapse.

**VS Solution:** Generate diverse synthetic examples that improve downstream model performance.

**Research Result:** Models fine-tuned on VS-generated math problems outperformed those trained on direct-prompting data by 5-7% on benchmarks.

**Best Practices:**
- Use VS-Multi for maximum diversity across a dataset
- Generate problem variations, not just solutions
- Lower probability threshold for more unusual examples

**Example (Math Problem Generation):**

Task: Generate competition math problems

Direct: Produces similar algebraic manipulation problems.

VS: Produces geometry, number theory, combinatorics, calculus applications, word problems with varied contexts.

## Text-to-Image Prompts

**Problem:** "Astronaut on a horse" always generates photorealistic desert scenes.

**VS Solution:** Generate diverse image descriptions, then feed to image generator.

**Best Practices:**
- Generate 5-10 image prompt variations
- Explicitly request style diversity (illustration, oil painting, minimalist, etc.)
- Select from distribution based on desired aesthetic

**Example:**

Direct: "An astronaut riding a horse in a desert, photorealistic, cinematic lighting" (x5)

VS Outputs:
1. "Watercolor illustration: astronaut and horse floating in space, dreamy, soft edges" (0.08)
2. "Art deco poster: geometric astronaut on stylized horse, gold and teal" (0.06)
3. "Medieval manuscript style: astronaut as knight, illuminated border" (0.05)
4. "Ukiyo-e woodblock: astronaut on horse crossing bridge, Mount Fuji background" (0.04)
5. "Children's book illustration: friendly astronaut, cartoon horse, primary colors" (0.07)

## Brainstorming & Ideation

**Problem:** First ideas are conventional. Need to push past obvious solutions.

**VS Solution:** Explicitly sample from low-probability (unconventional) regions.

**Best Practices:**
- Set tau = 0.05 or lower for maximum unconventionality
- Use VS-Multi to exhaustively explore idea space
- Combine high-probability (practical) and low-probability (creative) ideas

**Example:**

Task: "Ideas for a mobile app"

VS with tau = 0.05:
1. App that randomly assigns you a stranger to meet for coffee (0.04)
2. Competitive sleeping tracker with leaderboards (0.03)
3. App that generates fake but realistic background noise for calls (0.05)
4. Subscription service for surprise physical mail from your future self (0.02)
5. AI that watches your screen and judges your productivity in real-time (0.04)

## When NOT to Use VS

VS is optimized for tasks where diversity is valuable. Avoid for:

- **Factual questions with single correct answers:** "What is 2+2?"
- **Safety-critical applications:** Where predictability matters more than creativity
- **Highly constrained outputs:** Code that must compile, specific format requirements
- **When quality >> diversity:** Sometimes you just want the best answer

## Diversity-Quality Tradeoff

VS shifts the Pareto frontier, but there's still a tradeoff:

| tau | Diversity | Quality | Best For |
|-----|-----------|---------|----------|
| 0.20+ | Low | Highest | Near-best answer with some variety |
| 0.10 | Medium | High | Balanced exploration |
| 0.05 | High | Medium | Creative brainstorming |
| 0.01 | Maximum | Lower | Unusual/unconventional ideas |

**Recommendation:** Start with tau = 0.10, adjust based on task needs.
