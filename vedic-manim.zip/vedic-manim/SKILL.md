---
name: vedic-manim
description: Create educational explanation videos using Manim to demonstrate Vedic Mathematics concepts. Use this skill when users request videos, animations, or visual explanations of Vedic Math techniques such as multiplication methods, squaring techniques, or mental calculation strategies. This skill provides reusable scene classes, rendering utilities, and comprehensive references for both Vedic Mathematics methods and Manim animation patterns.
---

# Vedic Manim - Vedic Mathematics Video Creator

This skill enables creation of professional educational videos that explain Vedic Mathematics concepts using the Manim (Mathematical Animation Engine) library. It provides pre-built scene classes for common Vedic Math techniques, rendering utilities, and comprehensive reference materials.

## When to Use This Skill

Use this skill when:
- Creating explanation videos for Vedic Mathematics techniques
- Animating mental calculation methods and shortcuts
- Visualizing mathematical patterns in Vedic calculations
- Building educational content for multiplication, squaring, or division methods
- Demonstrating step-by-step solutions using Vedic sutras

## Prerequisites

Before using this skill, ensure Manim is installed:

```bash
pip install manim --break-system-packages
```

For LaTeX support (optional but recommended for mathematical notation):
```bash
sudo apt-get update
sudo apt-get install texlive texlive-latex-extra texlive-fonts-extra
```

## Core Components

### 1. Pre-built Scene Classes (`scripts/vedic_scenes.py`)

Ready-to-use Manim scene classes for common Vedic Math techniques:

#### CrosswiseMultiplication
Implements the Vertically and Crosswise (Urdhva Tiryagbhyam) method for general multiplication.

**Usage**:
```python
from vedic_scenes import CrosswiseMultiplication

class MyScene(CrosswiseMultiplication):
    def construct(self):
        super().construct(num1="23", num2="14")
```

**Visual Elements**:
- Splits numbers into individual digits
- Draws crossing lines between digits
- Shows three steps: ones place, cross multiplication, tens place
- Displays final answer in green

**Best for**: Two-digit multiplication, explaining the general Vedic multiplication method

#### NikhilamMethod
Implements the "All from 9 and Last from 10" method for numbers close to powers of 10.

**Usage**:
```python
from vedic_scenes import NikhilamMethod

class MyScene(NikhilamMethod):
    def construct(self):
        super().construct(num1="98", num2="97", base=100)
```

**Visual Elements**:
- Shows base (10, 100, 1000, etc.)
- Calculates and highlights deviations in red
- Demonstrates left part (crosswise sum)
- Shows right part (product of deviations)
- Combines into final answer

**Best for**: Multiplying numbers like 98×97, 103×102, 997×995

#### SquaringNearBase
Uses the Yavadunam sutra for squaring numbers close to a base.

**Usage**:
```python
from vedic_scenes import SquaringNearBase

class MyScene(SquaringNearBase):
    def construct(self):
        super().construct(num="103", base=100)
```

**Visual Elements**:
- Displays number and base
- Shows deviation in yellow
- Left part: number + deviation
- Right part: square of deviation
- Final answer with proper place values

**Best for**: Squares like 103², 98², 1003²

#### DigitSumVisualization
Demonstrates the Beejank (digit sum) verification method.

**Usage**:
```python
from vedic_scenes import DigitSumVisualization

class MyScene(DigitSumVisualization):
    def construct(self):
        super().construct(number=322, operation="square")
```

**Visual Elements**:
- Shows step-by-step digit addition
- Reduces to single digit
- Displays final digit sum in green

**Best for**: Verifying calculations, explaining the casting out nines method

### 2. Rendering Utility (`scripts/render_vedic.py`)

Helper script to render videos with appropriate settings for educational content.

**Basic Usage**:
```bash
python scripts/render_vedic.py CrosswiseMultiplication high ./output
```

**Render All Examples**:
```bash
python scripts/render_vedic.py all
```

**Quality Settings**:
- `low`: 480p, 15fps (fast preview)
- `medium`: 720p, 30fps (standard)
- `high`: 1080p, 60fps (recommended)
- `production`: 4K, 60fps (final delivery)

### 3. Reference Materials

#### `references/vedic_methods.md`
Comprehensive guide to Vedic Mathematics techniques including:
- All 16 main Vedic sutras with explanations
- Common multiplication techniques
- Step-by-step method breakdowns
- Number patterns and special cases
- Animation design guidelines (colors, timing, hierarchy)
- Verification methods

**Load this reference when**: Understanding the mathematical concepts behind a technique, designing new animations, or explaining why a method works.

#### `references/manim_reference.md`
Quick reference for Manim API patterns used in Vedic Math animations:
- Common Mobjects (Text, MathTex, shapes)
- Positioning and alignment methods
- Animation types and timing
- Color palettes
- Layout patterns specific to Vedic Math
- Performance tips
- Rendering commands

**Load this reference when**: Writing custom scene code, troubleshooting animations, or implementing new visualization patterns.

## Workflow for Creating Videos

### Standard Workflow (Using Pre-built Scenes)

1. **Identify the technique**: Determine which Vedic Math method to demonstrate
2. **Select appropriate scene**: Choose from CrosswiseMultiplication, NikhilamMethod, SquaringNearBase, or DigitSumVisualization
3. **Render the video**: Use `render_vedic.py` with appropriate parameters
4. **Review and iterate**: Check the output and adjust if needed

Example:
```bash
# Render a crosswise multiplication video
python scripts/render_vedic.py CrosswiseMultiplication high ./vedic_videos
```

### Custom Workflow (Creating New Scenes)

1. **Read references**: Start by reading `references/vedic_methods.md` to understand the mathematical technique
2. **Design visualization**: Plan the visual elements, steps, and timing
3. **Write scene class**: Create a new scene class, inheriting from `VedicMultiplicationScene` or `Scene`
4. **Reference Manim patterns**: Use `references/manim_reference.md` for API patterns
5. **Test and iterate**: Render at low quality for quick feedback
6. **Final render**: Produce high-quality version

Example custom scene structure:
```python
from manim import *
from vedic_scenes import VedicMultiplicationScene

class CustomVedicScene(VedicMultiplicationScene):
    def construct(self):
        # Setup
        title = self.setup_calculation_grid("15", "15", "Squaring Numbers Ending in 5")
        
        # Your custom animation steps
        # ... (refer to manim_reference.md for patterns)
        
        # Final result
        result = Text("225", font_size=72, color=GREEN).to_edge(DOWN)
        self.play(Write(result))
        self.wait(2)
```

### Batch Production Workflow

For creating multiple related videos:

1. **Plan the series**: List all techniques/examples to cover
2. **Modify scene classes**: Update parameters in scene classes or create variants
3. **Batch render**: Use a shell script or the `render_all_examples()` function
4. **Quality control**: Review all outputs for consistency

## Best Practices

### Animation Design
- Keep each video 30-90 seconds (one concept per video)
- Use consistent color scheme: Yellow for highlights, Red for deviations, Green for answers
- Allow 2-3 seconds per calculation step for viewer comprehension
- Include title card and final answer display
- Use Write() for text, Create() for geometric elements

### Code Organization
- Inherit from `VedicMultiplicationScene` for common setup
- Extract repetitive patterns into helper methods
- Keep scene classes focused on single techniques
- Use descriptive variable names for clarity

### Educational Effectiveness
- Show the problem clearly before solving
- Explain each step with text annotations
- Highlight patterns visually (crossing lines, deviations)
- Include verification step when appropriate
- End with clear final answer

### Performance
- Use medium quality for drafts (faster rendering)
- Test with `-ql` flag for rapid iteration
- Reserve high/production quality for final outputs
- Clear objects from scene when no longer needed

## Common Patterns

### Creating a Basic Calculation Flow

```python
# 1. Show problem
problem = MathTex("23 \\times 14").shift(UP * 2)
self.play(Write(problem))
self.wait()

# 2. Show method name
method = Text("Vertically and Crosswise", font_size=40).to_edge(UP)
self.play(Write(method))

# 3. Step-by-step calculations
step1 = Text("Step 1: 3 × 4 = 12", font_size=36).to_edge(DOWN)
self.play(Write(step1))
self.wait(2)
self.play(FadeOut(step1))

# 4. Final answer
answer = Text("= 322", font_size=72, color=GREEN).next_to(problem, RIGHT)
self.play(Write(answer))
self.wait(2)
```

### Highlighting Cross Connections

```python
# Draw lines showing cross multiplication
line1 = Line(digit1.get_center(), digit4.get_center(), 
            color=YELLOW, stroke_width=3)
line2 = Line(digit2.get_center(), digit3.get_center(),
            color=YELLOW, stroke_width=3)

self.play(Create(line1), Create(line2))
self.highlight_step(line1)  # Using helper method
```

### Progressive Disclosure

```python
# Show elements one at a time
self.play(Write(title))
self.wait(0.5)
self.play(FadeIn(numbers))
self.wait(0.5)
self.play(Create(grid))
# Continue building scene gradually
```

## Troubleshooting

### Manim Not Found
Ensure Manim is installed: `pip install manim --break-system-packages`

### LaTeX Errors
Install required LaTeX packages or use Text() instead of MathTex() for simple expressions

### Video Doesn't Render
- Check scene class name matches the one passed to manim command
- Verify file paths are correct
- Try lower quality setting first (`-ql`)

### Animations Too Fast/Slow
- Adjust `run_time` parameter: `self.play(Write(text), run_time=2)`
- Modify `self.wait()` durations between steps

### Object Positioning Issues
- Use `obj.move_to(ORIGIN)` to center
- Reference positions: `obj.next_to(other, UP)`
- Debug with `obj.get_center()` to check coordinates

## Extending the Skill

To add new Vedic Math techniques:

1. Study the technique in `references/vedic_methods.md`
2. Design the visual flow on paper
3. Create new scene class in `scripts/vedic_scenes.py`
4. Reference existing scenes for code patterns
5. Test with low quality renders
6. Add to `render_vedic.py` for easy access

Example additions to consider:
- Division methods (Paravartya Yojayet)
- Ekadhikena Purvena for numbers ending in 5
- Polynomial multiplication
- Solving equations
- Cube calculations

## Additional Resources

### Inside This Skill
- `scripts/vedic_scenes.py` - Pre-built scene classes
- `scripts/render_vedic.py` - Rendering utility
- `references/vedic_methods.md` - Vedic Math techniques and design guidelines
- `references/manim_reference.md` - Manim API patterns

### External Resources
- Manim Community Documentation: https://docs.manim.community/
- Vedic Mathematics Sutras: Traditional texts on 16 sutras
- Example videos: Search "Vedic Mathematics" on educational platforms

## Summary

This skill provides everything needed to create professional Vedic Mathematics explanation videos:
- Pre-built scenes for common techniques (multiplication, squaring, verification)
- Rendering utilities for easy video generation
- Comprehensive references for both math concepts and animation patterns
- Best practices for educational content

Start with the pre-built scenes, explore the references when creating custom animations, and follow the design guidelines for effective educational videos.
