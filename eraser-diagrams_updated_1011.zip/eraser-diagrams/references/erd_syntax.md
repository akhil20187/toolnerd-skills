# Entity Relationship Diagram (ERD) Syntax Reference

Complete syntax reference for Eraser.io Entity Relationship Diagrams.

## Entities

Entities represent database tables or similar data structures.

### Entity Definition
```
entityName [property: value] {
  attribute type metadata
  attribute2 type2 metadata2
}
```

Entity names must be unique within a diagram.

### Entity Properties

#### icon
Visual identifier from Eraser's icon library.

**Common icons:**
- `user`, `users` - User tables
- `folder`, `file` - Document/file tables
- `shopping-cart`, `shopping-bag` - Commerce tables
- `message-circle`, `mail` - Communication tables
- `calendar`, `clock` - Time-based tables
- `settings`, `tool` - Configuration tables

**Example:**
```
users [icon: user, color: blue]
products [icon: shopping-cart, color: green]
```

#### color
Color identifier or value for the entity.

**Example:**
```
orders [icon: shopping-bag, color: orange]
```

#### label
Display name different from the entity name.

**Example:**
```
usr_tbl [icon: user, label: Users]
```

## Attributes

Attributes represent columns in database tables.

### Attribute Definition
```
attributeName type metadata
```

Format is: `name` `type` `metadata` separated by spaces.

### Attribute Types

Common data types:
- `string` - Text/varchar
- `int` / `integer` - Integer numbers
- `float` / `decimal` - Decimal numbers
- `boolean` / `bool` - True/false values
- `timestamp` / `datetime` - Date and time
- `date` - Date only
- `time` - Time only
- `json` - JSON data
- `text` - Long text
- `uuid` - Universally unique identifier

**Example:**
```
users {
  id uuid
  email string
  age int
  balance decimal
  isActive boolean
  createdAt timestamp
}
```

### Attribute Metadata

#### Primary Key (pk)
Marks an attribute as the primary key.

```
users {
  id string pk
  email string
}
```

#### Foreign Key (fk)
Marks an attribute as a foreign key (optional, can also use relationship statements).

```
posts {
  id string pk
  userId string fk
}
```

#### unique
Marks an attribute as having a unique constraint.

```
users {
  id string pk
  email string unique
}
```

#### null / not null
Specifies whether the attribute can be null.

```
profiles {
  id string pk
  bio text null
  userId string not null
}
```

#### Multiple Metadata
Combine metadata with spaces:

```
users {
  id string pk not null
  email string unique not null
}
```

## Relationships

Relationships connect entities and show how data relates across tables.

### Inline Relationships

Define relationships inside entity definitions using relationship operators:

```
posts {
  id string pk
  title string
  userId < users.id
}
```

### Separate Relationship Statements

Define relationships as separate statements after entities:

```
posts.userId > users.id
```

### Relationship Syntax

Reference attributes using dot notation: `entityName.attributeName`

**Examples:**
```
// Inside entity
users {
  teamId < teams.id
}

// Outside entity
posts.authorId > users.id
comments.postId > posts.id
```

## Cardinality

Relationship arrows indicate cardinality:

### One-to-Many (>)
One record relates to many records.

```
users.id < posts.userId
// Or equivalently:
posts.userId > users.id
```

**Meaning:** One user has many posts.

### Many-to-One (<)
Many records relate to one record.

```
posts.userId > users.id
// Or equivalently:
users.id < posts.userId
```

**Meaning:** Many posts belong to one user.

### Many-to-Many (<>)
Records on both sides can have multiple relationships.

```
students.id <> courses.id
```

**Meaning:** Students can enroll in many courses, courses can have many students.

**Note:** For many-to-many relationships, you typically need a junction table:

```
students [icon: user] {
  id string pk
  name string
}

courses [icon: book] {
  id string pk
  title string
}

enrollments [icon: link] {
  studentId > students.id
  courseId > courses.id
  enrolledAt timestamp
}
```

## Styling

### Color Mode
```
colorMode: monochrome
```

**Options:**
- `colored` (default)
- `monochrome`

### Style Mode
```
styleMode: rounded
```

**Options:**
- `plain` (default)
- `rounded`

### Typeface
```
typeface: arial
```

## Complete Examples

### Social Media Platform
```
users [icon: user, color: blue] {
  id uuid pk
  username string unique not null
  email string unique not null
  passwordHash string not null
  displayName string
  bio text null
  avatarUrl string null
  createdAt timestamp not null
}

posts [icon: file-text, color: green] {
  id uuid pk
  authorId uuid not null
  content text not null
  mediaUrl string null
  likeCount int
  commentCount int
  createdAt timestamp not null
  updatedAt timestamp null
}

comments [icon: message-circle, color: orange] {
  id uuid pk
  postId uuid not null
  authorId uuid not null
  content text not null
  createdAt timestamp not null
}

likes [icon: heart, color: red] {
  id uuid pk
  postId uuid null
  commentId uuid null
  userId uuid not null
  createdAt timestamp not null
}

follows [icon: users, color: purple] {
  followerId uuid not null
  followingId uuid not null
  createdAt timestamp not null
}

// Relationships
posts.authorId > users.id
comments.postId > posts.id
comments.authorId > users.id
likes.postId > posts.id
likes.commentId > comments.id
likes.userId > users.id
follows.followerId > users.id
follows.followingId > users.id
```

### E-commerce Database
```
customers [icon: user, color: blue] {
  id string pk
  email string unique
  firstName string
  lastName string
  phone string
  createdAt timestamp
}

products [icon: shopping-cart, color: green] {
  id string pk
  name string
  description text
  price decimal
  stock int
  categoryId > categories.id
}

categories [icon: folder, color: purple] {
  id string pk
  name string
  parentId string null
}

orders [icon: shopping-bag, color: orange] {
  id string pk
  customerId > customers.id
  orderDate timestamp
  status string
  totalAmount decimal
  shippingAddress string
}

orderItems [icon: list, color: yellow] {
  id string pk
  orderId > orders.id
  productId > products.id
  quantity int
  unitPrice decimal
  subtotal decimal
}

payments [icon: credit-card, color: red] {
  id string pk
  orderId > orders.id
  paymentMethod string
  amount decimal
  status string
  transactionId string unique
  processedAt timestamp
}

reviews [icon: star, color: orange] {
  id string pk
  productId > products.id
  customerId > customers.id
  rating int
  comment text
  createdAt timestamp
}

// Hierarchical category relationship
categories.parentId > categories.id
```

### Project Management System
```
users [icon: user, color: blue] {
  id uuid pk
  email string unique not null
  name string not null
  role string not null
  createdAt timestamp
}

teams [icon: users, color: purple] {
  id uuid pk
  name string not null
  description text
  ownerId > users.id
}

teamMembers [icon: user-check] {
  teamId > teams.id
  userId > users.id
  role string
  joinedAt timestamp
}

projects [icon: folder, color: green] {
  id uuid pk
  name string not null
  description text
  teamId > teams.id
  startDate date
  endDate date null
  status string
}

tasks [icon: check-square, color: orange] {
  id uuid pk
  projectId > projects.id
  title string not null
  description text
  assigneeId > users.id
  priority string
  status string
  dueDate timestamp null
  createdAt timestamp
  completedAt timestamp null
}

comments [icon: message-circle, color: gray] {
  id uuid pk
  taskId > tasks.id
  authorId > users.id
  content text not null
  createdAt timestamp
}

attachments [icon: paperclip] {
  id uuid pk
  taskId > tasks.id
  uploadedBy > users.id
  fileName string
  fileUrl string
  fileSize int
  uploadedAt timestamp
}
```

### SaaS Application
```
organizations [icon: briefcase, color: blue] {
  id uuid pk
  name string unique not null
  domain string unique
  plan string not null
  billingEmail string
  createdAt timestamp
}

users [icon: user, color: green] {
  id uuid pk
  email string unique not null
  name string
  organizationId > organizations.id
  role string
  lastLoginAt timestamp null
}

workspaces [icon: home, color: purple] {
  id uuid pk
  name string not null
  organizationId > organizations.id
  createdBy > users.id
  createdAt timestamp
}

documents [icon: file-text, color: orange] {
  id uuid pk
  title string not null
  content text
  workspaceId > workspaces.id
  authorId > users.id
  createdAt timestamp
  updatedAt timestamp
}

permissions [icon: shield, color: red] {
  id uuid pk
  userId > users.id
  resourceType string
  resourceId uuid
  permissionLevel string
  grantedAt timestamp
}

apiKeys [icon: key, color: gray] {
  id uuid pk
  name string
  keyHash string unique
  organizationId > organizations.id
  createdBy > users.id
  expiresAt timestamp null
  createdAt timestamp
}

auditLogs [icon: clock, color: gray] {
  id uuid pk
  userId > users.id
  action string
  resourceType string
  resourceId uuid
  metadata json
  timestamp timestamp
}
```

## Best Practices

1. **Use meaningful entity names** - Lowercase, plural nouns (users, orders, products)
2. **Always include id and timestamps** - Standard practice for most tables
3. **Mark primary keys** - Use `pk` metadata on id fields
4. **Use appropriate data types** - Match types to actual data (uuid for IDs, timestamp for dates)
5. **Add unique constraints** - Mark email and other unique fields with `unique`
6. **Document nullability** - Explicitly mark nullable fields when relevant
7. **Use icons strategically** - Icons make ERDs more scannable and intuitive
8. **Group related entities** - Use colors to categorize related tables
9. **Show all relationships** - Don't leave foreign keys without relationship lines
10. **Consider junction tables** - Use junction tables for many-to-many relationships
