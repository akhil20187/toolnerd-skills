#!/usr/bin/env python3
"""
Helper script to generate Vedic Mathematics videos using Manim.
Handles scene rendering with optimal settings for educational content.
"""

import subprocess
import sys
import os
from pathlib import Path


def render_vedic_video(scene_name, output_dir="./vedic_videos", quality="high", 
                       num1=None, num2=None, base=None):
    """
    Render a Vedic Mathematics scene using Manim.
    
    Args:
        scene_name: Name of the scene class (e.g., 'CrosswiseMultiplication')
        output_dir: Directory to save the rendered video
        quality: 'low', 'medium', 'high', or 'production'
        num1: First number (for multiplication scenes)
        num2: Second number (for multiplication scenes)
        base: Base for Nikhilam method or squaring
    
    Returns:
        Path to the rendered video file
    """
    
    # Quality settings
    quality_flags = {
        'low': '-ql',      # 480p, 15fps
        'medium': '-qm',   # 720p, 30fps
        'high': '-qh',     # 1080p, 60fps
        'production': '-qk' # 4K, 60fps
    }
    
    quality_flag = quality_flags.get(quality, '-qh')
    
    # Get the script directory
    script_dir = Path(__file__).parent
    scenes_file = script_dir / "vedic_scenes.py"
    
    if not scenes_file.exists():
        raise FileNotFoundError(f"vedic_scenes.py not found at {scenes_file}")
    
    # Build the command
    cmd = [
        'manim',
        quality_flag,
        str(scenes_file),
        scene_name,
        '--output_dir', output_dir
    ]
    
    # Add custom arguments if provided
    if num1 or num2 or base:
        # Note: For custom parameters, we'd need to modify the approach
        # This is a simplified version - in practice, you might use
        # config files or modify the scene classes
        print(f"Note: Custom parameters (num1={num1}, num2={num2}, base={base}) "
              f"require modifying the scene class directly.")
    
    print(f"Rendering {scene_name}...")
    print(f"Command: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print(result.stdout)
        print(f"✅ Video rendered successfully!")
        
        # Find the output file
        output_path = Path(output_dir) / "videos" / scenes_file.stem / quality
        if output_path.exists():
            video_files = list(output_path.glob("*.mp4"))
            if video_files:
                return video_files[0]
        
        return None
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error rendering video:")
        print(e.stderr)
        sys.exit(1)


def render_all_examples(output_dir="./vedic_videos"):
    """Render example videos for all Vedic Math techniques."""
    
    scenes = [
        "CrosswiseMultiplication",
        "NikhilamMethod",
        "SquaringNearBase",
        "DigitSumVisualization"
    ]
    
    print("Rendering all example scenes...")
    
    for scene in scenes:
        print(f"\n{'='*50}")
        print(f"Rendering: {scene}")
        print('='*50)
        render_vedic_video(scene, output_dir=output_dir, quality="medium")
    
    print("\n✅ All scenes rendered!")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python render_vedic.py <scene_name> [quality] [output_dir]")
        print("  python render_vedic.py all  # Render all example scenes")
        print("\nAvailable scenes:")
        print("  - CrosswiseMultiplication")
        print("  - NikhilamMethod")
        print("  - SquaringNearBase")
        print("  - DigitSumVisualization")
        print("\nQuality options: low, medium, high, production")
        sys.exit(1)
    
    scene_name = sys.argv[1]
    quality = sys.argv[2] if len(sys.argv) > 2 else "high"
    output_dir = sys.argv[3] if len(sys.argv) > 3 else "./vedic_videos"
    
    if scene_name.lower() == "all":
        render_all_examples(output_dir)
    else:
        render_vedic_video(scene_name, output_dir, quality)
