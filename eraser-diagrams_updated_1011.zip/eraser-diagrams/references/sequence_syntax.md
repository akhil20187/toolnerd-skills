# Sequence Diagram Syntax Reference

Complete syntax reference for Eraser.io sequence diagrams.

## Messages

Messages represent interactions between entities (columns) in a sequence diagram.

### Message Syntax
```
Column1 [properties] > Column2 [properties]: Message text
```

Components:
- **Column1**: Source entity name
- **>**: Arrow indicating direction (always left-to-right)
- **Column2**: Target entity name
- **:**: Separator before message text
- **Message text**: Description of the interaction

### Column Auto-Creation

Columns are automatically created the first time they are referenced. No explicit column definition needed.

```
Client > Server: Request data
// Creates both "Client" and "Server" columns automatically
```

### Sequential Processing

Lines are processed top-to-bottom and rendered in that order.

```
Client > Server: Request 1
Server > Database: Query 1
Database > Server: Results 1
Server > Client: Response 1
Client > Server: Request 2
```

## Column Properties

Properties customize the appearance and information of columns.

### icon
Visual identifier for the column.

**Common icons:**
- Clients: `monitor`, `phone`, `tablet`, `user`
- Servers: `server`, `cloud`, `database`, `cpu`
- Services: `shield`, `key`, `mail`, `message-circle`
- External: `globe`, `external-link`

**Example:**
```
Client [icon: monitor] > Server [icon: server]: Request
```

### color
Color identifier for the column.

**Common colors:** `blue`, `red`, `green`, `orange`, `purple`, `yellow`, `gray`, `pink`

**Example:**
```
WebApp [icon: monitor, color: blue] > API [icon: server, color: green]: GET /users
```

### label
Display name for the column (different from internal name).

**Use case:** When you need the display text to differ from the internal identifier.

**Example:**
```
usr_svc [icon: server, label: User Service] > db [icon: database, label: PostgreSQL]: Query users
```

### Multiple Properties

Separate multiple properties with commas:

```
Frontend [icon: monitor, color: blue, label: React App] > Backend [icon: server, color: green, label: Node.js API]: POST /api/login
```

## Control Flow Blocks

Control flow blocks represent conditional logic, loops, and parallel execution.

### alt (Alternative Paths)

Represents if-else conditional logic.

**Syntax:**
```
alt [label: condition] {
  // Messages when condition is true
} else [label: alternative condition] {
  // Messages when condition is false
}
```

**Example:**
```
Client > Server: Login request
Server > Database: Verify credentials

alt [label: credentials valid] {
  Server > TokenService: Generate token
  TokenService > Server: JWT token
  Server > Client: 200 OK
} else [label: credentials invalid] {
  Server > Client: 401 Unauthorized
}
```

### par (Parallel Execution)

Represents concurrent or parallel operations.

**Syntax:**
```
par [label: first parallel task] {
  // First parallel flow
} and [label: second parallel task] {
  // Second parallel flow
}
```

**Example:**
```
API > Database: Start transaction

par [label: fetch user data] {
  API > UserService: Get user profile
  UserService > Database: Query users table
  Database > UserService: User data
  UserService > API: Profile data
} and [label: fetch user posts] {
  API > PostService: Get user posts
  PostService > Database: Query posts table
  Database > PostService: Posts data
  PostService > API: Posts data
}

API > Client: Combined response
```

### loop (Repeated Execution)

Represents iterative operations.

**Syntax:**
```
loop [label: condition] {
  // Messages that repeat
}
```

**Example:**
```
Client > Server: Request batch processing

loop [label: for each item] {
  Server > Processor: Process item
  Processor > Database: Save result
  Database > Processor: Confirmation
  Processor > Server: Item complete
}

Server > Client: All items processed
```

### opt (Optional Execution)

Represents conditional execution without an else branch.

**Syntax:**
```
opt [label: condition] {
  // Messages that execute conditionally
}
```

**Example:**
```
Client > Server: Submit order
Server > Database: Create order record

opt [label: promotional code provided] {
  Server > DiscountService: Validate code
  DiscountService > Database: Check code validity
  Database > DiscountService: Code details
  DiscountService > Server: Apply discount
}

Server > Client: Order confirmation
```

### critical (Critical Section)

Represents a critical section that must execute atomically.

**Syntax:**
```
critical [label: section description] {
  // Messages in critical section
}
```

**Example:**
```
Service1 > Database: Begin transaction

critical [label: atomic payment processing] {
  Service1 > PaymentGateway: Charge card
  PaymentGateway > Service1: Payment confirmed
  Service1 > Database: Update balance
  Database > Service1: Balance updated
}

Service1 > Database: Commit transaction
```

## Activations

Activations show when a column (entity) is actively processing.

### Activation Syntax

**Start activation:**
```
activate ColumnName
```

**End activation:**
```
deactivate ColumnName
```

**Example:**
```
Client > Server: Request data
activate Server

Server > Database: Query
activate Database
Database > Server: Results
deactivate Database

Server > Cache: Store results
Server > Client: Response
deactivate Server
```

### Multiple Activations

Columns can be activated multiple times, creating nested activations.

```
Client > Server: Request 1
activate Server
Server > Database: Query 1
Database > Server: Result 1
Server > Client: Response 1

Client > Server: Request 2
activate Server  // Server now has 2 activation levels
Server > Database: Query 2
Database > Server: Result 2
Server > Client: Response 2
deactivate Server  // Back to 1 activation level
deactivate Server  // Now deactivated
```

## Comments

Add comments using `//`:

```
// This is a comment
Client > Server: Request data
// Comments help document complex flows
Server > Database: Query
```

## Special Characters

Reserved characters: `>`, `:`, `{`, `}`, `[`, `]`

To use these characters in column or message text, wrap in double quotes:

```
"User/Admin" [icon: user] > "API/Gateway" [icon: server]: GET /api/v1/resource
```

## Styling

### Color Mode
```
colorMode: monochrome
```

**Options:**
- `colored` (default)
- `monochrome`

### Style Mode
```
styleMode: rounded
```

**Options:**
- `plain` (default)
- `rounded`

## Complete Examples

### User Authentication Flow
```
// User login with JWT authentication
Client [icon: monitor, color: blue] > API [icon: server, color: green]: POST /auth/login
activate API

API > AuthService [icon: shield, color: orange]: Validate credentials
activate AuthService

AuthService > Database [icon: database]: Query user by email
Database > AuthService: User record

alt [label: password matches] {
  AuthService > TokenService [icon: key]: Generate JWT
  activate TokenService
  TokenService > AuthService: JWT token
  deactivate TokenService
  
  AuthService > Database: Update last_login
  AuthService > API: Auth success + token
  API > Client: 200 OK {token, user}
  
} else [label: password invalid] {
  AuthService > API: Auth failed
  API > Client: 401 Unauthorized
}

deactivate AuthService
deactivate API
```

### E-commerce Order Processing
```
// Complete order flow with payment and inventory
Customer [icon: user, color: blue] > WebApp [icon: monitor, color: purple]: Place order
activate WebApp

WebApp > API [icon: server, color: green]: POST /orders
activate API

// Validate order
API > ValidationService [icon: check-circle, color: orange]: Validate order
activate ValidationService
ValidationService > Database [icon: database]: Check product availability
Database > ValidationService: Stock levels
ValidationService > API: Validation result
deactivate ValidationService

alt [label: items available] {
  
  // Process payment
  API > PaymentService [icon: credit-card, color: red]: Process payment
  activate PaymentService
  PaymentService > PaymentGateway [icon: external-link]: Charge card
  PaymentGateway > PaymentService: Payment confirmed
  PaymentService > Database: Record transaction
  PaymentService > API: Payment success
  deactivate PaymentService
  
  // Update inventory and create order
  par [label: update inventory] {
    API > InventoryService [icon: package]: Reserve items
    activate InventoryService
    InventoryService > Database: Update stock
    Database > InventoryService: Stock updated
    InventoryService > API: Items reserved
    deactivate InventoryService
  } and [label: create order record] {
    API > OrderService [icon: shopping-bag]: Create order
    activate OrderService
    OrderService > Database: Insert order
    Database > OrderService: Order created
    OrderService > API: Order ID
    deactivate OrderService
  }
  
  // Notify customer
  API > NotificationService [icon: mail, color: yellow]: Send confirmation
  activate NotificationService
  NotificationService > EmailProvider [icon: external-link]: Send email
  NotificationService > Customer: Email sent
  deactivate NotificationService
  
  API > WebApp: Order confirmed
  WebApp > Customer: Success message
  
} else [label: items unavailable] {
  API > WebApp: Out of stock error
  WebApp > Customer: Error message
}

deactivate API
deactivate WebApp
```

### Microservices API Request Flow
```
// Complex microservices interaction with caching
Client [icon: phone, color: blue] > APIGateway [icon: server, color: green]: GET /users/123/profile
activate APIGateway

APIGateway > AuthMiddleware [icon: shield, color: orange]: Verify token
activate AuthMiddleware
AuthMiddleware > TokenCache [icon: database, color: red]: Check token
TokenCache > AuthMiddleware: Token valid
deactivate AuthMiddleware

APIGateway > UserService [icon: server, color: purple]: GET /users/123
activate UserService

// Check cache first
UserService > Cache [icon: database, color: red]: Get user:123
Cache > UserService: Cache miss

// Fetch from database
UserService > Database [icon: database]: SELECT * FROM users WHERE id=123
activate Database
Database > UserService: User data
deactivate Database

// Fetch additional data in parallel
par [label: fetch posts] {
  UserService > PostService [icon: server, color: green]: GET /posts?userId=123
  activate PostService
  PostService > PostDatabase [icon: database]: Query posts
  PostDatabase > PostService: Posts data
  PostService > UserService: Posts list
  deactivate PostService
} and [label: fetch followers] {
  UserService > SocialService [icon: server, color: blue]: GET /followers/123
  activate SocialService
  SocialService > SocialDatabase [icon: database]: Query followers
  SocialDatabase > SocialService: Followers data
  SocialService > UserService: Followers count
  deactivate SocialService
}

// Update cache
UserService > Cache: Set user:123 (TTL: 5min)

UserService > APIGateway: Complete profile data
deactivate UserService

APIGateway > Client: 200 OK with profile
deactivate APIGateway
```

### Saga Pattern Distributed Transaction
```
// Saga pattern for order fulfillment
OrderService [icon: shopping-bag, color: blue] > EventBus [icon: server, color: purple]: OrderCreated event
activate EventBus

// Step 1: Reserve inventory
EventBus > InventoryService [icon: package, color: green]: Reserve items
activate InventoryService
InventoryService > InventoryDB [icon: database]: Update stock
InventoryDB > InventoryService: Stock reserved

alt [label: inventory available] {
  InventoryService > EventBus: InventoryReserved event
  deactivate InventoryService
  
  // Step 2: Process payment
  EventBus > PaymentService [icon: credit-card, color: red]: Charge customer
  activate PaymentService
  PaymentService > PaymentGateway [icon: external-link]: Process payment
  PaymentGateway > PaymentService: Payment result
  
  alt [label: payment successful] {
    PaymentService > EventBus: PaymentProcessed event
    deactivate PaymentService
    
    // Step 3: Arrange shipping
    EventBus > ShippingService [icon: truck, color: orange]: Create shipment
    activate ShippingService
    ShippingService > ShippingProvider [icon: external-link]: Book courier
    ShippingProvider > ShippingService: Shipment confirmed
    ShippingService > EventBus: ShipmentScheduled event
    deactivate ShippingService
    
    // Success path
    EventBus > OrderService: Order completed
    OrderService > NotificationService [icon: mail]: Send confirmation
    
  } else [label: payment failed] {
    PaymentService > EventBus: PaymentFailed event
    deactivate PaymentService
    
    // Compensating transaction: Release inventory
    EventBus > InventoryService: Compensate - Release items
    activate InventoryService
    InventoryService > InventoryDB: Restore stock
    InventoryService > EventBus: InventoryReleased event
    deactivate InventoryService
    
    EventBus > OrderService: Order failed
  }
  
} else [label: insufficient inventory] {
  InventoryService > EventBus: InventoryUnavailable event
  deactivate InventoryService
  EventBus > OrderService: Order cancelled
}

deactivate EventBus
```

### OAuth 2.0 Authorization Code Flow
```
// Complete OAuth 2.0 flow
User [icon: user, color: blue] > ClientApp [icon: monitor, color: purple]: Click "Login with OAuth"
activate ClientApp

ClientApp > User: Redirect to authorization server
User > AuthServer [icon: shield, color: orange]: GET /authorize
activate AuthServer

// User authentication
AuthServer > User: Show login page
User > AuthServer: Submit credentials

AuthServer > UserDB [icon: database]: Verify credentials
activate UserDB
UserDB > AuthServer: User verified
deactivate UserDB

// User consent
AuthServer > User: Show consent page
User > AuthServer: Grant permissions

// Generate authorization code
AuthServer > AuthServer: Generate auth code
AuthServer > User: Redirect with code
deactivate AuthServer

// Exchange code for token
User > ClientApp: Authorization code
ClientApp > AuthServer: POST /token (code + client_secret)
activate AuthServer

AuthServer > AuthServer: Validate code & client
AuthServer > TokenDB [icon: database]: Generate tokens
activate TokenDB
TokenDB > AuthServer: Access + refresh tokens
deactivate TokenDB

AuthServer > ClientApp: Tokens
deactivate AuthServer

// Access protected resource
ClientApp > ResourceServer [icon: server, color: green]: GET /api/user (with access token)
activate ResourceServer

ResourceServer > AuthServer: Validate access token
activate AuthServer
AuthServer > ResourceServer: Token valid + scopes
deactivate AuthServer

ResourceServer > ResourceDB [icon: database]: Fetch user data
ResourceDB > ResourceServer: User data
ResourceServer > ClientApp: Protected resource
deactivate ResourceServer

ClientApp > User: Show user data
deactivate ClientApp
```

## Best Practices

1. **Use clear column names** - Descriptive names for all entities
2. **Apply icons appropriately** - Use icons that match entity types
3. **Show activations** - Indicate when entities are actively processing
4. **Use control blocks** - Represent conditional logic with alt/opt blocks
5. **Leverage parallel blocks** - Show concurrent operations with par blocks
6. **Add message descriptions** - Provide clear text for all interactions
7. **Group related messages** - Use control blocks to organize related flows
8. **Keep messages horizontal** - Messages always flow left-to-right
9. **Comment complex flows** - Add comments to explain business logic
10. **Use colors strategically** - Color-code layers or categories of services
