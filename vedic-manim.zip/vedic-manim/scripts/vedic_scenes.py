#!/usr/bin/env python3
"""
Reusable Manim scene classes for Vedic Mathematics visualizations.
These classes provide common patterns for animating Vedic Math concepts.
"""

from manim import *


class VedicMultiplicationScene(Scene):
    """
    Base scene for Vedic multiplication techniques.
    Provides common setup for multiplication visualizations.
    """
    
    def setup_calculation_grid(self, num1, num2, title="Vedic Multiplication"):
        """Setup the basic grid and title for multiplication problems."""
        title_text = Text(title, font_size=48).to_edge(UP)
        self.play(Write(title_text))
        self.wait(0.5)
        return title_text
    
    def highlight_step(self, mobject, color=YELLOW):
        """Highlight a step in the calculation."""
        self.play(Indicate(mobject, color=color, scale_factor=1.2))
        self.wait(0.3)


class CrosswiseMultiplication(VedicMultiplicationScene):
    """
    Implements the Vertically and Crosswise (Urdhva Tiryagbhyam) method.
    Example: 23 × 14
    """
    
    def construct(self, num1="23", num2="14"):
        # Title
        title = self.setup_calculation_grid(num1, num2, 
                                           "Vertically and Crosswise Method")
        
        # Display numbers
        n1 = Text(num1, font_size=72).shift(UP * 1.5 + LEFT * 2)
        n2 = Text(num2, font_size=72).shift(UP * 1.5 + RIGHT * 2)
        times = Text("×", font_size=60).shift(UP * 1.5)
        
        self.play(Write(n1), Write(times), Write(n2))
        self.wait()
        
        # Split digits
        n1_digits = [Text(d, font_size=60).move_to(n1.get_center() + RIGHT * (i * 0.5 - 0.25)) 
                     for i, d in enumerate(num1)]
        n2_digits = [Text(d, font_size=60).move_to(n2.get_center() + RIGHT * (i * 0.5 - 0.25)) 
                     for i, d in enumerate(num2)]
        
        self.play(
            Transform(n1, VGroup(*n1_digits)),
            Transform(n2, VGroup(*n2_digits))
        )
        self.wait()
        
        # Step 1: Rightmost digits (ones place)
        step1_text = Text("Step 1: Multiply rightmost digits", 
                         font_size=36).to_edge(DOWN).shift(UP * 0.5)
        self.play(Write(step1_text))
        
        d1_right = int(num1[-1])
        d2_right = int(num2[-1])
        ones_calc = Text(f"{d1_right} × {d2_right} = {d1_right * d2_right}", 
                        font_size=40).next_to(step1_text, UP)
        
        self.play(Write(ones_calc))
        self.wait()
        
        # Step 2: Cross multiplication (tens place)
        self.play(FadeOut(step1_text), FadeOut(ones_calc))
        step2_text = Text("Step 2: Cross multiply and add", 
                         font_size=36).to_edge(DOWN).shift(UP * 0.5)
        self.play(Write(step2_text))
        
        d1_left = int(num1[0])
        d2_left = int(num2[0])
        
        cross_calc = Text(f"({d1_left} × {d2_right}) + ({d1_right} × {d2_left}) = "
                         f"{d1_left * d2_right + d1_right * d2_left}", 
                         font_size=40).next_to(step2_text, UP)
        
        # Draw cross lines
        line1 = Line(n1_digits[0].get_center(), n2_digits[1].get_center(), 
                    color=YELLOW, stroke_width=3)
        line2 = Line(n1_digits[1].get_center(), n2_digits[0].get_center(), 
                    color=YELLOW, stroke_width=3)
        
        self.play(Create(line1), Create(line2))
        self.play(Write(cross_calc))
        self.wait()
        
        # Step 3: Leftmost digits (hundreds place)
        self.play(FadeOut(step2_text), FadeOut(cross_calc), 
                 FadeOut(line1), FadeOut(line2))
        step3_text = Text("Step 3: Multiply leftmost digits", 
                         font_size=36).to_edge(DOWN).shift(UP * 0.5)
        self.play(Write(step3_text))
        
        hundreds_calc = Text(f"{d1_left} × {d2_left} = {d1_left * d2_left}", 
                           font_size=40).next_to(step3_text, UP)
        
        self.play(Write(hundreds_calc))
        self.wait()
        
        # Final result
        result = int(num1) * int(num2)
        self.play(FadeOut(step3_text), FadeOut(hundreds_calc))
        final_text = Text(f"Final Answer: {result}", 
                         font_size=48, color=GREEN).to_edge(DOWN)
        self.play(Write(final_text))
        self.wait(2)


class NikhilamMethod(VedicMultiplicationScene):
    """
    Implements the Nikhilam (All from 9 and last from 10) method.
    Best for numbers close to powers of 10.
    Example: 98 × 97
    """
    
    def construct(self, num1="98", num2="97", base=100):
        title = self.setup_calculation_grid(num1, num2, 
                                           "Nikhilam Method (Near Base)")
        
        # Display numbers and base
        n1 = Text(num1, font_size=60).shift(UP * 1 + LEFT * 2)
        n2 = Text(num2, font_size=60).shift(UP * 1 + RIGHT * 2)
        base_text = Text(f"Base: {base}", font_size=40).shift(UP * 2)
        
        self.play(Write(base_text))
        self.play(Write(n1), Write(n2))
        self.wait()
        
        # Calculate deviations
        dev1 = int(num1) - base
        dev2 = int(num2) - base
        
        dev1_text = Text(f"{dev1:+d}", font_size=40, color=RED).next_to(n1, RIGHT)
        dev2_text = Text(f"{dev2:+d}", font_size=40, color=RED).next_to(n2, RIGHT)
        
        explanation = Text("Step 1: Find deviations from base", 
                          font_size=36).to_edge(DOWN)
        self.play(Write(explanation))
        self.play(Write(dev1_text), Write(dev2_text))
        self.wait()
        
        # Left part (main answer)
        self.play(FadeOut(explanation))
        left_explanation = Text(f"Step 2: {num1} + ({dev2}) = {int(num1) + dev2}", 
                               font_size=36).to_edge(DOWN)
        left_result = int(num1) + dev2
        
        self.play(Write(left_explanation))
        self.wait()
        
        # Right part (multiplied deviations)
        self.play(FadeOut(left_explanation))
        right_explanation = Text(f"Step 3: {dev1} × {dev2} = {dev1 * dev2}", 
                                font_size=36).to_edge(DOWN)
        right_result = dev1 * dev2
        
        self.play(Write(right_explanation))
        self.wait()
        
        # Combine results
        result = int(num1) * int(num2)
        self.play(FadeOut(right_explanation))
        final_text = Text(f"Result: {left_result}|{abs(right_result):02d} = {result}", 
                         font_size=48, color=GREEN).to_edge(DOWN)
        self.play(Write(final_text))
        self.wait(2)


class SquaringNearBase(VedicMultiplicationScene):
    """
    Squaring numbers close to a base using Yavadunam sutra.
    Example: 103² (near base 100)
    """
    
    def construct(self, num="103", base=100):
        title = Text("Squaring Near Base Method", font_size=48).to_edge(UP)
        self.play(Write(title))
        
        # Display number and base
        num_text = Text(f"{num}²", font_size=72).shift(UP)
        base_text = Text(f"Base: {base}", font_size=40).shift(UP * 2)
        
        self.play(Write(base_text))
        self.play(Write(num_text))
        self.wait()
        
        # Calculate deviation
        n = int(num)
        deviation = n - base
        
        dev_text = Text(f"Deviation: {deviation:+d}", 
                       font_size=40, color=YELLOW).next_to(num_text, DOWN)
        self.play(Write(dev_text))
        self.wait()
        
        # Left part: number + deviation
        step1 = Text(f"Left part: {num} + {deviation} = {n + deviation}", 
                    font_size=36).to_edge(DOWN).shift(UP * 1)
        self.play(Write(step1))
        self.wait()
        
        # Right part: deviation squared
        step2 = Text(f"Right part: {deviation}² = {deviation ** 2}", 
                    font_size=36).to_edge(DOWN)
        self.play(Write(step2))
        self.wait()
        
        # Final result
        result = n ** 2
        self.play(FadeOut(step1), FadeOut(step2))
        final = Text(f"Answer: {n + deviation}|{abs(deviation ** 2):02d} = {result}", 
                    font_size=48, color=GREEN).to_edge(DOWN)
        self.play(Write(final))
        self.wait(2)


class DigitSumVisualization(Scene):
    """
    Visualize the digit sum check (Beejank) for verification.
    """
    
    def construct(self, number, operation="square"):
        title = Text("Verification: Digit Sum Check (Beejank)", 
                    font_size=40).to_edge(UP)
        self.play(Write(title))
        
        num_text = Text(str(number), font_size=60).shift(UP)
        self.play(Write(num_text))
        
        # Calculate digit sum
        def digit_sum(n):
            while n > 9:
                n = sum(int(d) for d in str(n))
            return n
        
        steps = []
        current = number
        while current > 9:
            steps.append(current)
            current = sum(int(d) for d in str(current))
        
        # Animate digit sum calculation
        explanation = Text("Add digits until single digit", 
                          font_size=30).next_to(num_text, DOWN)
        self.play(Write(explanation))
        
        for i, step in enumerate(steps):
            step_text = Text(f"{step} → {sum(int(d) for d in str(step))}", 
                           font_size=40).next_to(explanation, DOWN * (i + 1))
            self.play(Write(step_text))
            self.wait(0.5)
        
        final_digit_sum = digit_sum(number)
        result = Text(f"Digit Sum: {final_digit_sum}", 
                     font_size=48, color=GREEN).to_edge(DOWN)
        self.play(Write(result))
        self.wait(2)
