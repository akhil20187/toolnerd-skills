# BPMN Diagram (Swimlane) Syntax Reference

Complete syntax reference for Eraser.io BPMN diagrams.

## Overview

BPMN (Business Process Model and Notation) diagrams visualize business processes using:
- **Pools**: Top-level containers representing organizations or departments
- **Lanes**: Sub-containers within pools representing roles or sub-organizations
- **Flow Objects**: Activities, events, and gateways that describe the process

## Pools

Pools are top-level containers that typically represent organizations, departments, or major participants.

### Pool Definition
```
PoolName {
  // Flow objects and lanes
}
```

Outermost brackets `{ }` are automatically interpreted as pools.

### Example
```
CustomerService {
  ReceiveRequest [type: activity]
  ProcessRequest [type: activity]
}

Warehouse {
  ShipOrder [type: activity]
}
```

## Lanes

Lanes are sub-containers within pools that typically represent roles or sub-organizations.

### Lane Definition
```
DepartmentName {
  RoleName {
    // Flow objects
  }
}
```

Inner nested brackets within a pool are interpreted as lanes.

### Example
```
OrderManagement {
  SalesRep {
    ReceiveOrder [type: activity]
    ValidateOrder [type: activity]
  }
  
  Manager {
    ApproveOrder [type: gateway]
    ReviewException [type: activity]
  }
}
```

## Flow Objects

Flow objects are the building blocks of BPMN diagrams representing tasks, events, and decision points.

### Flow Object Definition
```
ObjectName [type: flowObjectType, icon: iconName, color: colorValue, label: displayText]
```

### Flow Object Types

#### activity (default)
Represents tasks or actions in the process.

**Example:**
```
ProcessPayment [type: activity]
ValidateInput [type: activity]
SendNotification [type: activity]
```

#### event
Represents start points, end points, or milestones in the process.

**Example:**
```
OrderReceived [type: event]
PaymentComplete [type: event]
ProcessEnd [type: event]
```

#### gateway
Represents decision points or branching in the process.

**Example:**
```
CheckInventory [type: gateway, label: Items Available?]
ValidOrder [type: gateway, label: Order Valid?]
ApprovedByManager [type: gateway, label: Approved?]
```

### Flow Object Properties

#### type
Specifies the type of flow object. If omitted, defaults to `activity`.

**Options:** `activity`, `event`, `gateway`

#### icon
Visual identifier for the flow object.

**Common icons:**
- Actions: `check`, `x`, `alert-circle`, `info`, `edit`
- Communication: `mail`, `message-circle`, `phone`, `send`
- Files: `file`, `folder`, `upload`, `download`
- Business: `briefcase`, `dollar-sign`, `shopping-cart`, `package`

#### color
Color identifier for the flow object.

**Common colors:** `blue`, `red`, `green`, `orange`, `purple`, `yellow`, `gray`

#### label
Display text shown in the diagram (different from internal name).

**CRITICAL:** Labels cannot contain these special characters: `{`, `}`, `[`, `]`, `<`, `>`, `:`, `,`, `/`

Use alternative characters instead:
- Use `()` instead of `[]` - e.g., `Complete? (Unknown)` not `Complete? [Unknown]`
- Use `-` or `|` instead of `/` - e.g., `Complete-Incomplete` not `Complete/Incomplete`
- Use words instead of symbols - e.g., `Amount greater than 100K` not `Amount > 100K`

**Examples:**
```
// ✅ CORRECT
CheckStock [type: gateway, icon: package, label: Inventory Available?]
IsComplete [type: gateway, label: Complete? (Unknown)]
ApproveAmount [type: gateway, label: Amount greater than 100K?]

// ❌ WRONG - Contains forbidden characters in label
CheckStock [type: gateway, label: Stock > 0?]
IsComplete [type: gateway, label: Complete? [Unknown]]
Decide [type: gateway, label: Go/No-Go?]
```

### Multiple Properties

Separate multiple properties with commas:
```
ProcessOrder [type: activity, icon: shopping-cart, color: blue, label: Process Customer Order]
```

## Connections

Connections represent the flow between activities, events, and gateways.

### Basic Connection
```
FlowObject1 > FlowObject2
```

### Labeled Connection
```
Gateway > Activity: Label text
```

### Multiple Targets
```
Activity1 > Activity2, Activity3, Activity4
```

### Conditional Flow from Gateway
```
CheckInventory > FulfillOrder: In Stock
CheckInventory > BackOrder: Out of Stock
```

## Special Characters

### In Flow Object Names

Reserved characters: `{`, `}`, `[`, `]`, `>`, `<`, `:`, `,`, `/`

To use these characters in flow object, pool, or lane **names**, wrap the entire name in double quotes:

```
Customer {
  "Place / Cancel Order" [type: activity]
  "Ready to Ship?" [type: gateway]
}
```

### In Labels (Property Values)

**CRITICAL:** The `label` property **cannot contain** these special characters even with quotes: `{`, `}`, `[`, `]`, `<`, `>`, `:`, `,`, `/`

You must use alternative characters in label values:

```
// ✅ CORRECT - Alternative characters used in labels
CheckInventory [type: gateway, label: Stock Available?]
ValidateAmount [type: gateway, label: Amount greater than 100K?]
ReviewStatus [type: gateway, label: Complete? (Pending)]
ChoosePath [type: gateway, label: Approve or Reject?]

// ❌ WRONG - Forbidden characters in labels
CheckInventory [type: gateway, label: Stock > 0?]
ValidateAmount [type: gateway, label: Amount > $100K?]
ReviewStatus [type: gateway, label: Complete? [Pending]]
ChoosePath [type: gateway, label: Approve/Reject?]
```

**Common Replacements for Labels:**
- `>` → `greater than` or `more than`
- `<` → `less than` or `fewer than`
- `[]` → `()` parentheses
- `/` → `or`, `-`, or `|`
- `:` → `-` or omit
- `,` → `and` or `-`

## Styling

### Color Mode
```
colorMode: monochrome
```

**Options:**
- `colored` (default)
- `monochrome`

### Style Mode
```
styleMode: rounded
```

**Options:**
- `plain` (default)
- `rounded`

## Complete Examples

### Customer Order Fulfillment
```
// E-commerce order fulfillment process
Customer {
  BrowseProducts [type: activity, icon: search]
  AddToCart [type: activity, icon: shopping-cart]
  Checkout [type: activity, icon: credit-card]
  OrderPlaced [type: event, color: green]
}

OrderProcessing {
  SalesAgent {
    ReceiveOrder [type: activity]
    ValidateOrder [type: gateway, label: Valid Order?]
    ProcessPayment [type: activity, icon: credit-card]
    PaymentSuccess [type: event, color: green]
  }
  
  Supervisor {
    ReviewException [type: activity, color: orange]
    ResolveIssue [type: activity]
  }
}

Warehouse {
  Picker {
    ReceivePickList [type: activity]
    PickItems [type: activity, icon: package]
    PackOrder [type: activity, icon: box]
  }
  
  ShippingClerk {
    GenerateLabel [type: activity]
    ArrangeShipment [type: activity, icon: truck]
    OrderShipped [type: event, color: blue]
  }
}

// Process flow
BrowseProducts > AddToCart
AddToCart > Checkout
Checkout > OrderPlaced
OrderPlaced > ReceiveOrder
ReceiveOrder > ValidateOrder
ValidateOrder > ProcessPayment: Yes
ValidateOrder > ReviewException: No
ReviewException > ResolveIssue
ResolveIssue > ValidateOrder
ProcessPayment > PaymentSuccess
PaymentSuccess > ReceivePickList
ReceivePickList > PickItems
PickItems > PackOrder
PackOrder > GenerateLabel
GenerateLabel > ArrangeShipment
ArrangeShipment > OrderShipped
OrderShipped > Customer
```

### Employee Onboarding Process
```
// New employee onboarding workflow
HR {
  Recruiter {
    OfferAccepted [type: event, color: green]
    CreateProfile [type: activity, icon: user-plus]
    AssignBuddy [type: activity]
    ScheduleOrientation [type: activity, icon: calendar]
  }
  
  Coordinator {
    PrepareDocuments [type: activity, icon: file-text]
    OrderEquipment [type: activity, icon: monitor]
    SetupWorkspace [type: activity]
  }
}

IT {
  Administrator {
    CreateAccounts [type: activity, icon: key]
    ConfigureDevices [type: activity, icon: settings]
    GrantAccess [type: activity, icon: unlock]
  }
  
  HelpDesk {
    DeliverEquipment [type: activity, icon: package]
    ProvideTraining [type: activity, icon: book]
  }
}

Manager {
  ReviewOnboarding [type: activity]
  AssignProjects [type: activity, icon: briefcase]
  ScheduleMeetings [type: activity, icon: calendar]
}

NewEmployee {
  AttendOrientation [type: activity]
  CompleteTraining [type: activity, icon: award]
  StartWork [type: event, color: blue]
}

// Process flow
OfferAccepted > CreateProfile
CreateProfile > PrepareDocuments, OrderEquipment, CreateAccounts
PrepareDocuments > ScheduleOrientation
OrderEquipment > ConfigureDevices
CreateAccounts > ConfigureDevices
ConfigureDevices > GrantAccess
GrantAccess > DeliverEquipment
ScheduleOrientation > AttendOrientation
AttendOrientation > ProvideTraining
ProvideTraining > CompleteTraining
DeliverEquipment > SetupWorkspace
SetupWorkspace > AssignBuddy
AssignBuddy > ReviewOnboarding
ReviewOnboarding > AssignProjects, ScheduleMeetings
CompleteTraining > AssignProjects
AssignProjects > StartWork
```

### Loan Application Process
```
// Bank loan application and approval workflow
Applicant {
  SubmitApplication [type: activity, icon: file-text]
  ProvideDocuments [type: activity, icon: upload]
  ReceiveDecision [type: event]
}

LoanProcessing {
  LoanOfficer {
    ReceiveApplication [type: activity]
    ReviewApplication [type: activity, icon: search]
    InitialCheck [type: gateway, label: Complete Application?]
    RequestDocuments [type: activity, icon: mail]
    VerifyDocuments [type: activity, icon: check]
  }
  
  Underwriter {
    CreditCheck [type: activity, icon: dollar-sign]
    IncomeVerification [type: activity]
    RiskAssessment [type: activity, icon: alert-circle]
    RiskLevel [type: gateway, label: Risk Level?]
  }
  
  SeniorUnderwriter {
    ReviewHighRisk [type: activity, color: red]
    MakeDecision [type: gateway, label: Approved?]
  }
}

Management {
  BranchManager {
    FinalApproval [type: gateway, label: Amount > $100K?]
    ApproveHighValue [type: activity, color: orange]
  }
}

Legal {
  PrepareLoanAgreement [type: activity, icon: file-text]
  ReviewCompliance [type: activity, icon: shield]
}

Finance {
  SetupAccount [type: activity, icon: database]
  DisburseFunds [type: activity, icon: dollar-sign]
  FundsTransferred [type: event, color: green]
}

// Process flow
SubmitApplication > ReceiveApplication
ReceiveApplication > ReviewApplication
ReviewApplication > InitialCheck
InitialCheck > VerifyDocuments: Complete
InitialCheck > RequestDocuments: Incomplete
RequestDocuments > ProvideDocuments
ProvideDocuments > VerifyDocuments
VerifyDocuments > CreditCheck
CreditCheck > IncomeVerification
IncomeVerification > RiskAssessment
RiskAssessment > RiskLevel

RiskLevel > FinalApproval: Low/Medium Risk
RiskLevel > ReviewHighRisk: High Risk

ReviewHighRisk > MakeDecision
MakeDecision > FinalApproval: Approved
MakeDecision > ReceiveDecision: Rejected

FinalApproval > PrepareLoanAgreement: Amount <= $100K
FinalApproval > ApproveHighValue: Amount > $100K
ApproveHighValue > PrepareLoanAgreement

PrepareLoanAgreement > ReviewCompliance
ReviewCompliance > SetupAccount
SetupAccount > DisburseFunds
DisburseFunds > FundsTransferred
FundsTransferred > ReceiveDecision
```

### Software Development Workflow
```
// Agile software development process
ProductManagement {
  ProductOwner {
    DefineFeature [type: activity, icon: file-text]
    CreateUserStory [type: activity, icon: edit]
    PrioritizeBacklog [type: activity, icon: list]
  }
}

Development {
  TechLead {
    ReviewStory [type: activity]
    DesignSolution [type: activity, icon: code]
    EstimateEffort [type: activity]
  }
  
  Developer {
    PickUpStory [type: activity]
    WriteCode [type: activity, icon: code]
    WriteTests [type: activity, icon: check-square]
    CodeComplete [type: event, color: blue]
  }
}

QualityAssurance {
  QAEngineer {
    CreateTestPlan [type: activity, icon: file-text]
    ExecuteTests [type: activity, icon: play]
    TestResult [type: gateway, label: Tests Pass?]
    LogBug [type: activity, color: red]
  }
  
  QALead {
    FinalVerification [type: activity, icon: check-circle]
    ApproveRelease [type: gateway, label: Release Ready?]
  }
}

Operations {
  DevOpsEngineer {
    PrepareDeployment [type: activity, icon: package]
    DeployToStaging [type: activity, icon: server]
    DeployToProduction [type: activity, icon: cloud]
    ReleaseComplete [type: event, color: green]
  }
  
  SysAdmin {
    MonitorDeployment [type: activity, icon: activity]
    VerifyHealth [type: activity, icon: heart]
  }
}

// Process flow
DefineFeature > CreateUserStory
CreateUserStory > ReviewStory
ReviewStory > DesignSolution
DesignSolution > EstimateEffort
EstimateEffort > PrioritizeBacklog
PrioritizeBacklog > PickUpStory
PickUpStory > CreateTestPlan
PickUpStory > WriteCode
WriteCode > WriteTests
WriteTests > CodeComplete
CodeComplete > ExecuteTests

ExecuteTests > TestResult
TestResult > FinalVerification: Pass
TestResult > LogBug: Fail
LogBug > PickUpStory

FinalVerification > ApproveRelease
ApproveRelease > PrepareDeployment: Approved
ApproveRelease > ReviewStory: Not Ready

PrepareDeployment > DeployToStaging
DeployToStaging > MonitorDeployment
MonitorDeployment > VerifyHealth
VerifyHealth > DeployToProduction
DeployToProduction > ReleaseComplete
```

### Healthcare Patient Care Workflow
```
// Hospital patient care process
Patient {
  ArriveAtHospital [type: event, icon: user]
  CheckIn [type: activity]
  WaitForDoctor [type: activity, icon: clock]
  ReceiveTreatment [type: activity]
  Discharged [type: event, color: green]
}

Reception {
  Receptionist {
    RegisterPatient [type: activity, icon: edit]
    VerifyInsurance [type: activity, icon: shield]
    CollectCopay [type: activity, icon: dollar-sign]
  }
}

Nursing {
  TriageNurse {
    AssessSymptoms [type: activity, icon: heart]
    RecordVitals [type: activity, icon: activity]
    PriorityLevel [type: gateway, label: Urgency?]
  }
  
  FloorNurse {
    PrepareRoom [type: activity]
    AdministerMedication [type: activity, icon: package]
    MonitorPatient [type: activity]
  }
}

Medical {
  Doctor {
    ExaminePatient [type: activity, icon: search]
    OrderTests [type: gateway, label: Tests Needed?]
    DiagnoseCondition [type: activity]
    PrescribeTreatment [type: activity, icon: file-text]
  }
  
  Specialist {
    PerformSpecializedExam [type: activity]
    ProvideRecommendation [type: activity]
  }
}

Laboratory {
  LabTechnician {
    CollectSample [type: activity, icon: droplet]
    RunTests [type: activity, icon: settings]
    AnalyzeResults [type: activity]
    SendResults [type: activity, icon: send]
  }
}

Pharmacy {
  Pharmacist {
    ReceivePrescription [type: activity]
    PrepareMedication [type: activity, icon: package]
    ProvideInstructions [type: activity, icon: info]
  }
}

Billing {
  BillingClerk {
    GenerateInvoice [type: activity, icon: file-text]
    ProcessPayment [type: activity, icon: credit-card]
    SubmitInsuranceClaim [type: activity, icon: send]
  }
}

// Process flow
ArriveAtHospital > CheckIn
CheckIn > RegisterPatient
RegisterPatient > VerifyInsurance
VerifyInsurance > CollectCopay
CollectCopay > AssessSymptoms
AssessSymptoms > RecordVitals
RecordVitals > PriorityLevel

PriorityLevel > ExaminePatient: Normal
PriorityLevel > PrepareRoom: Urgent
PrepareRoom > MonitorPatient

WaitForDoctor > ExaminePatient
ExaminePatient > OrderTests

OrderTests > CollectSample: Yes
OrderTests > DiagnoseCondition: No

CollectSample > RunTests
RunTests > AnalyzeResults
AnalyzeResults > SendResults
SendResults > DiagnoseCondition

DiagnoseCondition > PerformSpecializedExam: Complex Case
PerformSpecializedExam > ProvideRecommendation
ProvideRecommendation > PrescribeTreatment

DiagnoseCondition > PrescribeTreatment: Standard Case
PrescribeTreatment > ReceivePrescription
ReceivePrescription > PrepareMedication
PrepareMedication > ProvideInstructions
ProvideInstructions > AdministerMedication
AdministerMedication > ReceiveTreatment
ReceiveTreatment > GenerateInvoice
GenerateInvoice > ProcessPayment
ProcessPayment > SubmitInsuranceClaim
SubmitInsuranceClaim > Discharged
```

## Best Practices

1. **Use meaningful pool names** - Represent actual organizations or departments
2. **Define clear lanes** - Represent specific roles or responsibilities
3. **Apply appropriate flow object types** - Use activities for tasks, events for milestones, gateways for decisions
4. **Label gateways clearly** - Make decision points obvious with descriptive questions
5. **Show complete flows** - Connect all flow objects to show the entire process
6. **Use icons strategically** - Icons improve readability and comprehension
7. **Apply colors meaningfully** - Use colors to highlight important steps or status
8. **Group related activities** - Keep related tasks in the same lane
9. **Show exception paths** - Include error handling and alternative paths
10. **Keep it focused** - Include essential steps, avoid over-complication
11. **Document handoffs** - Show clearly when responsibility moves between lanes
12. **Use consistent naming** - Apply consistent terminology throughout the diagram
