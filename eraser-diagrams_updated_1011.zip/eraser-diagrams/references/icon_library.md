# Eraser.io Icon Library Reference

Comprehensive catalog of built-in icons available in Eraser.io diagrams.

## General Icons

### Users & People
- `user` - Single user
- `users` - Multiple users/group
- `user-plus` - Add user
- `user-minus` - Remove user
- `user-check` - Verified user
- `user-x` - Blocked user

### Actions & Status
- `check` - Checkmark/success
- `check-circle` - Circled checkmark
- `check-square` - Checked box
- `x` - Cross/close
- `x-circle` - Circled cross
- `alert-circle` - Warning
- `alert-triangle` - Caution
- `info` - Information
- `help-circle` - Help/question

### Communication
- `mail` - Email
- `message-circle` - Chat message
- `message-square` - Square message
- `phone` - Telephone
- `phone-call` - Active call
- `send` - Send message
- `inbox` - Inbox
- `bell` - Notification

### Files & Documents
- `file` - Generic file
- `file-text` - Text document
- `folder` - Folder
- `folder-plus` - Add folder
- `upload` - Upload
- `download` - Download
- `paperclip` - Attachment
- `archive` - Archive
- `copy` - Copy
- `edit` - Edit/pencil

### Technology & Computing
- `server` - Server
- `database` - Database
- `cloud` - Cloud
- `monitor` - Desktop monitor
- `smartphone` - Mobile phone
- `tablet` - Tablet device
- `cpu` - Processor
- `hard-drive` - Storage drive
- `code` - Code/programming
- `terminal` - Command line
- `settings` - Settings/config
- `tool` - Tools
- `package` - Package/module

### Networking & Security
- `wifi` - WiFi/wireless
- `globe` - Internet/world
- `external-link` - External link
- `link` - Link/connection
- `shield` - Security/protection
- `lock` - Locked
- `unlock` - Unlocked
- `key` - Key/access

### Business & Commerce
- `briefcase` - Business/work
- `shopping-cart` - Shopping cart
- `shopping-bag` - Shopping bag
- `credit-card` - Payment card
- `dollar-sign` - Money/payment
- `trending-up` - Growth/increase
- `trending-down` - Decline
- `bar-chart` - Bar chart
- `pie-chart` - Pie chart
- `activity` - Activity/analytics

### Navigation & UI
- `home` - Home
- `menu` - Menu
- `more-horizontal` - More options
- `search` - Search
- `filter` - Filter
- `refresh-cw` - Refresh/reload
- `arrow-right` - Right arrow
- `arrow-left` - Left arrow
- `arrow-up` - Up arrow
- `arrow-down` - Down arrow
- `chevron-right` - Right chevron
- `chevron-left` - Left chevron

### Media & Content
- `image` - Image/photo
- `video` - Video
- `play` - Play
- `pause` - Pause
- `camera` - Camera
- `mic` - Microphone
- `volume-2` - Speaker/audio
- `book` - Book
- `bookmark` - Bookmark

### Calendar & Time
- `calendar` - Calendar
- `clock` - Time/clock
- `watch` - Stopwatch

### Location & Travel
- `map` - Map
- `map-pin` - Location pin
- `navigation` - Navigation
- `compass` - Compass
- `truck` - Delivery truck

### Miscellaneous
- `star` - Star/favorite
- `heart` - Heart/like
- `award` - Award/badge
- `gift` - Gift
- `flag` - Flag
- `droplet` - Droplet/water
- `box` - Box/container
- `list` - List
- `grid` - Grid
- `layers` - Layers/stack

## AWS Icons

### Compute
- `aws-ec2` - EC2 (Elastic Compute Cloud)
- `aws-lambda` - Lambda Functions
- `aws-ecs` - ECS (Elastic Container Service)
- `aws-eks` - EKS (Elastic Kubernetes Service)
- `aws-fargate` - Fargate
- `aws-batch` - Batch
- `aws-lightsail` - Lightsail
- `aws-elastic-beanstalk` - Elastic Beanstalk

### Storage
- `aws-s3` - S3 (Simple Storage Service)
- `aws-ebs` - EBS (Elastic Block Store)
- `aws-efs` - EFS (Elastic File System)
- `aws-fsx` - FSx
- `aws-glacier` - Glacier
- `aws-storage-gateway` - Storage Gateway
- `aws-backup` - Backup

### Database
- `aws-rds` - RDS (Relational Database Service)
- `aws-dynamodb` - DynamoDB
- `aws-elasticache` - ElastiCache
- `aws-redshift` - Redshift
- `aws-aurora` - Aurora
- `aws-neptune` - Neptune (Graph DB)
- `aws-documentdb` - DocumentDB
- `aws-timestream` - Timestream
- `aws-keyspaces` - Keyspaces (Cassandra)

### Networking & Content Delivery
- `aws-vpc` - VPC (Virtual Private Cloud)
- `aws-route53` - Route 53 (DNS)
- `aws-cloudfront` - CloudFront (CDN)
- `aws-api-gateway` - API Gateway
- `aws-elb` - ELB (Elastic Load Balancing)
- `aws-alb` - ALB (Application Load Balancer)
- `aws-nlb` - NLB (Network Load Balancer)
- `aws-direct-connect` - Direct Connect
- `aws-vpn-gateway` - VPN Gateway
- `aws-transit-gateway` - Transit Gateway
- `aws-nat-gateway` - NAT Gateway
- `aws-global-accelerator` - Global Accelerator

### Integration & Messaging
- `aws-sqs` - SQS (Simple Queue Service)
- `aws-sns` - SNS (Simple Notification Service)
- `aws-kinesis` - Kinesis
- `aws-eventbridge` - EventBridge
- `aws-step-functions` - Step Functions
- `aws-mq` - MQ (Message Broker)
- `aws-appsync` - AppSync

### Analytics
- `aws-athena` - Athena
- `aws-emr` - EMR (Elastic MapReduce)
- `aws-glue` - Glue
- `aws-quicksight` - QuickSight
- `aws-data-pipeline` - Data Pipeline
- `aws-msk` - MSK (Managed Kafka)

### Security & Identity
- `aws-iam` - IAM (Identity & Access Management)
- `aws-cognito` - Cognito
- `aws-kms` - KMS (Key Management Service)
- `aws-secrets-manager` - Secrets Manager
- `aws-waf` - WAF (Web Application Firewall)
- `aws-shield` - Shield
- `aws-guardduty` - GuardDuty
- `aws-inspector` - Inspector
- `aws-macie` - Macie
- `aws-certificate-manager` - Certificate Manager

### Management & Monitoring
- `aws-cloudwatch` - CloudWatch
- `aws-cloudtrail` - CloudTrail
- `aws-xray` - X-Ray
- `aws-systems-manager` - Systems Manager
- `aws-cloudformation` - CloudFormation
- `aws-config` - Config
- `aws-organizations` - Organizations

### Developer Tools
- `aws-codecommit` - CodeCommit
- `aws-codebuild` - CodeBuild
- `aws-codedeploy` - CodeDeploy
- `aws-codepipeline` - CodePipeline
- `aws-cloud9` - Cloud9

### Other Services
- `aws-simple-email-service` - SES (Simple Email Service)
- `aws-workspaces` - WorkSpaces
- `aws-iot-core` - IoT Core
- `aws-amplify` - Amplify

## GCP Icons

### Compute
- `gcp-compute-engine` - Compute Engine (VMs)
- `gcp-cloud-functions` - Cloud Functions
- `gcp-cloud-run` - Cloud Run
- `gcp-gke` - GKE (Google Kubernetes Engine)
- `gcp-app-engine` - App Engine

### Storage
- `gcp-cloud-storage` - Cloud Storage
- `gcp-persistent-disk` - Persistent Disk
- `gcp-filestore` - Filestore

### Database
- `gcp-cloud-sql` - Cloud SQL
- `gcp-firestore` - Firestore
- `gcp-bigtable` - Bigtable
- `gcp-spanner` - Spanner
- `gcp-memorystore` - Memorystore (Redis)

### Networking
- `gcp-cloud-load-balancing` - Cloud Load Balancing
- `gcp-cloud-cdn` - Cloud CDN
- `gcp-cloud-dns` - Cloud DNS
- `gcp-cloud-vpn` - Cloud VPN
- `gcp-cloud-armor` - Cloud Armor
- `gcp-cloud-nat` - Cloud NAT

### Integration & Messaging
- `gcp-pubsub` - Pub/Sub
- `gcp-cloud-tasks` - Cloud Tasks
- `gcp-cloud-scheduler` - Cloud Scheduler
- `gcp-cloud-composer` - Cloud Composer (Airflow)

### Analytics & Big Data
- `gcp-bigquery` - BigQuery
- `gcp-dataflow` - Dataflow
- `gcp-dataproc` - Dataproc (Spark/Hadoop)
- `gcp-data-fusion` - Data Fusion
- `gcp-data-catalog` - Data Catalog

### AI & Machine Learning
- `gcp-ai-platform` - AI Platform
- `gcp-vision-api` - Vision API
- `gcp-natural-language-api` - Natural Language API
- `gcp-translation-api` - Translation API
- `gcp-speech-to-text` - Speech-to-Text
- `gcp-text-to-speech` - Text-to-Speech
- `gcp-automl` - AutoML

### Monitoring & Management
- `gcp-cloud-monitoring` - Cloud Monitoring
- `gcp-cloud-logging` - Cloud Logging
- `gcp-cloud-trace` - Cloud Trace
- `gcp-cloud-profiler` - Cloud Profiler
- `gcp-deployment-manager` - Deployment Manager

### Security
- `gcp-cloud-iam` - Cloud IAM
- `gcp-cloud-kms` - Cloud KMS
- `gcp-security-command-center` - Security Command Center

## Azure Icons

### Compute
- `azure-vm` - Virtual Machines
- `azure-functions` - Functions
- `azure-app-service` - App Service
- `azure-aks` - AKS (Azure Kubernetes Service)
- `azure-container-instances` - Container Instances
- `azure-batch` - Batch

### Storage
- `azure-storage` - Storage Accounts
- `azure-blob-storage` - Blob Storage
- `azure-file-storage` - File Storage
- `azure-disk-storage` - Disk Storage
- `azure-data-lake` - Data Lake

### Database
- `azure-sql-database` - SQL Database
- `azure-cosmos-db` - Cosmos DB
- `azure-cache-redis` - Azure Cache for Redis
- `azure-database-postgresql` - Azure Database for PostgreSQL
- `azure-database-mysql` - Azure Database for MySQL
- `azure-synapse-analytics` - Synapse Analytics

### Networking
- `azure-load-balancer` - Load Balancer
- `azure-application-gateway` - Application Gateway
- `azure-cdn` - CDN
- `azure-dns` - DNS
- `azure-vpn-gateway` - VPN Gateway
- `azure-expressroute` - ExpressRoute
- `azure-firewall` - Firewall
- `azure-front-door` - Front Door

### Integration & Messaging
- `azure-service-bus` - Service Bus
- `azure-event-grid` - Event Grid
- `azure-event-hubs` - Event Hubs
- `azure-logic-apps` - Logic Apps
- `azure-api-management` - API Management

### Analytics
- `azure-databricks` - Databricks
- `azure-data-factory` - Data Factory
- `azure-stream-analytics` - Stream Analytics
- `azure-hdinsight` - HDInsight

### AI & Cognitive Services
- `azure-cognitive-services` - Cognitive Services
- `azure-machine-learning` - Machine Learning
- `azure-bot-service` - Bot Service

### Security
- `azure-key-vault` - Key Vault
- `azure-active-directory` - Active Directory
- `azure-security-center` - Security Center

### Monitoring & Management
- `azure-monitor` - Monitor
- `azure-log-analytics` - Log Analytics
- `azure-application-insights` - Application Insights
- `azure-resource-manager` - Resource Manager

## Kubernetes Icons

### Core Objects
- `k8s-pod` - Pod
- `k8s-service` - Service
- `k8s-deployment` - Deployment
- `k8s-node` - Node
- `k8s-namespace` - Namespace
- `k8s-cluster` - Cluster

### Controllers
- `k8s-replicaset` - ReplicaSet
- `k8s-statefulset` - StatefulSet
- `k8s-daemonset` - DaemonSet
- `k8s-job` - Job
- `k8s-cronjob` - CronJob

### Configuration & Storage
- `k8s-configmap` - ConfigMap
- `k8s-secret` - Secret
- `k8s-pv` - PersistentVolume
- `k8s-pvc` - PersistentVolumeClaim
- `k8s-storage-class` - StorageClass

### Networking
- `k8s-ingress` - Ingress
- `k8s-network-policy` - NetworkPolicy
- `k8s-endpoint` - Endpoint

### Control Plane Components
- `k8s-control-plane` - Control Plane
- `k8s-api` - API Server
- `k8s-etcd` - etcd
- `k8s-scheduler` - Scheduler
- `k8s-c-m` - Controller Manager
- `k8s-c-c-m` - Cloud Controller Manager

### Node Components
- `k8s-kubelet` - Kubelet
- `k8s-k-proxy` - Kube Proxy

## Using Icons

### Syntax
```
NodeName [icon: iconName]
```

### Examples
```
// General icons
User [icon: user]
Database [icon: database]
API [icon: server]

// AWS icons
EC2Instance [icon: aws-ec2]
S3Bucket [icon: aws-s3]
RDSDatabase [icon: aws-rds]

// GCP icons
ComputeEngine [icon: gcp-compute-engine]
CloudStorage [icon: gcp-cloud-storage]
BigQueryDataset [icon: gcp-bigquery]

// Azure icons
VirtualMachine [icon: azure-vm]
BlobStorage [icon: azure-blob-storage]
SQLDatabase [icon: azure-sql-database]

// Kubernetes icons
AppPod [icon: k8s-pod]
LoadBalancerService [icon: k8s-service]
AppDeployment [icon: k8s-deployment]
```

## Best Practices

1. **Match icons to components** - Use icons that accurately represent the component type
2. **Be consistent** - Use the same icon for the same type of component throughout
3. **Use vendor-specific icons** - When showing cloud services, use the appropriate AWS/GCP/Azure icons
4. **Combine with colors** - Use icons with colors for better visual categorization
5. **Don't overuse** - Not every node needs an icon; use them where they add clarity
6. **Test readability** - Ensure icons are recognizable at the diagram's intended size

## Notes

- Icon availability may vary by diagram type
- Icons are case-sensitive (use lowercase with hyphens)
- If an icon doesn't exist, the diagram will still render but without the icon
- New icons are regularly added to Eraser's library
