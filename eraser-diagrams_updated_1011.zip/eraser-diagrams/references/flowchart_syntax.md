# Flow Chart Syntax Reference

Complete syntax reference for Eraser.io flow charts.

## Nodes

Nodes are the basic building blocks in flow charts.

### Node Definition
```
NodeName [property: value, property2: value2]
```

Node names must be unique within a diagram.

### Node Properties

#### shape
Visual shape of the node.

**Options:** 
- `rectangle` (default)
- `cylinder`
- `diamond`
- `document`
- `ellipse`
- `hexagon`
- `oval`
- `parallelogram`
- `star`
- `trapezoid`
- `triangle`

**Example:**
```
Start [shape: oval]
Decision [shape: diamond]
Process [shape: rectangle]
```

#### icon
Icon identifier from Eraser's built-in library.

**Common icons:**
- User/people: `user`, `users`, `user-check`, `user-plus`
- Actions: `check`, `x`, `alert-circle`, `info`
- Tech: `server`, `database`, `cloud`, `monitor`, `cpu`
- Communication: `mail`, `message-circle`, `phone`, `send`
- Files: `file`, `folder`, `upload`, `download`

**Example:**
```
UserInput [icon: user]
Server [icon: server]
Database [icon: database]
```

#### color
Color identifier or value.

**Common colors:** `blue`, `red`, `green`, `orange`, `purple`, `yellow`, `gray`, `pink`

**Example:**
```
Success [color: green]
Error [color: red]
Warning [color: orange]
```

#### label
Display text shown in the diagram (different from node name used in code).

**Use case:** When you need duplicate labels or want the display text to differ from the internal name.

**Example:**
```
Start_A [label: Start]
Start_B [label: Start]  // Same label, different names
```

### Multiple Properties

Separate multiple properties with commas:
```
UserLogin [shape: diamond, icon: user, color: blue, label: User Login?]
```

## Groups

Groups are containers that encapsulate nodes and other groups.

### Group Definition
```
GroupName {
  Node1, Node2, Node3
}
```

Or with newlines as separators:
```
GroupName {
  Node1
  Node2
  Node3
}
```

### Nested Groups

Groups can contain other groups:
```
OuterGroup {
  InnerGroup {
    Node1
    Node2
  }
  Node3
}
```

### Group Properties

Groups support the same properties as nodes: `icon`, `color`, `label`

**Example:**
```
AuthenticationSystem [color: blue, icon: shield] {
  ValidateUser
  GenerateToken
  LogActivity
}
```

## Connections

Connections represent relationships between nodes and groups.

### Basic Connection
```
Node1 > Node2
```

### Connection with Label
```
Node1 > Node2: Connection label
```

### Reverse Connection
```
Node1 < Node2
```

### Multiple Targets
```
Node1 > Node2, Node3, Node4
```

### Connection from Group
```
Group1 > Node1
```

### Connection to Group
```
Node1 > Group1
```

## Direction

Control the flow direction of the diagram:

```
direction: right
```

**Options:**
- `right` - Left to right (default)
- `left` - Right to left
- `up` - Bottom to top
- `down` - Top to bottom

## Styling

### Color Mode
```
colorMode: monochrome
```

**Options:**
- `colored` (default) - Uses specified colors
- `monochrome` - Grayscale rendering

### Style Mode
```
styleMode: rounded
```

**Options:**
- `plain` (default) - Sharp corners
- `rounded` - Rounded corners

### Typeface
```
typeface: arial
```

Various font options available.

## Special Characters

Reserved characters: `{`, `}`, `[`, `]`, `>`, `<`, `:`, `,`

To use these characters in node or group names, wrap the entire name in double quotes:

```
Customer {
  "Submit / Review Order" [type: activity]
  "Check Status?" [type: gateway]
}
```

## Complete Examples

### User Registration Flow
```
direction: down

Start [shape: oval]
EnterDetails [shape: rectangle, label: Enter Registration Details]
ValidateEmail [shape: diamond, label: Email Valid?]
CheckExisting [shape: diamond, label: User Exists?]
CreateAccount [shape: rectangle, color: green]
SendConfirmation [shape: rectangle]
ShowError [shape: rectangle, color: red]
End [shape: oval]

ValidationSystem [color: blue] {
  EmailValidator
  DuplicateChecker
  PasswordHasher
}

Start > EnterDetails
EnterDetails > EmailValidator
EmailValidator > ValidateEmail
ValidateEmail > DuplicateChecker: Yes
ValidateEmail > ShowError: No
DuplicateChecker > CheckExisting
CheckExisting > ShowError: Yes
CheckExisting > PasswordHasher: No
PasswordHasher > CreateAccount
CreateAccount > SendConfirmation
SendConfirmation > End
ShowError > End
```

### E-commerce Checkout Process
```
direction: right
styleMode: rounded

Browse [shape: oval, icon: search]
AddCart [icon: shopping-cart]
ViewCart [icon: shopping-bag]
Checkout [shape: diamond, icon: credit-card, label: Proceed?]
Login [shape: diamond, label: Logged in?]
EnterShipping [icon: truck]
ReviewOrder [icon: file-text]
ProcessPayment [icon: credit-card]
Confirm [shape: oval, icon: check, color: green]
Cancel [shape: oval, icon: x, color: red]

PaymentGateway [color: orange] {
  ValidateCard
  ProcessTransaction
  SendReceipt
}

Browse > AddCart > ViewCart > Checkout
Checkout > Login: Yes
Checkout > Cancel: No
Login > EnterShipping: Yes
Login > EnterShipping: No (Guest)
EnterShipping > ReviewOrder
ReviewOrder > ValidateCard
ValidateCard > ProcessPayment
ProcessPayment > ProcessTransaction
ProcessTransaction > SendReceipt
SendReceipt > Confirm
```

### Issue Triage Workflow
```
NewIssue [shape: oval, icon: alert-circle]
Categorize [shape: diamond, label: Issue Type?]
BugTriage [icon: bug, color: red]
FeatureReview [icon: star, color: blue]
QuestionReview [icon: help-circle, color: orange]

BugFixing {
  Investigate
  Reproduce
  Fix
  Test
}

FeaturePlanning {
  Evaluate
  Prioritize
  Schedule
}

AssignPriority [shape: diamond, label: Priority?]
HighPriority [color: red]
MediumPriority [color: orange]
LowPriority [color: yellow]
Resolved [shape: oval, icon: check-circle, color: green]

NewIssue > Categorize
Categorize > BugTriage: Bug
Categorize > FeatureReview: Feature
Categorize > QuestionReview: Question
BugTriage > Investigate
Investigate > Reproduce > Fix > Test > Resolved
FeatureReview > Evaluate
Evaluate > Prioritize > Schedule > Resolved
QuestionReview > AssignPriority
AssignPriority > HighPriority: High
AssignPriority > MediumPriority: Medium
AssignPriority > LowPriority: Low
HighPriority, MediumPriority, LowPriority > Resolved
```

## Best Practices

1. **Keep node names simple** - Use camelCase or snake_case for internal names
2. **Use labels for display** - When you need spaces or special characters
3. **Apply shapes meaningfully** - Ovals for start/end, diamonds for decisions
4. **Group related processes** - Use groups to show system boundaries
5. **Add connection labels** - Explain branching decisions and flow logic
6. **Choose direction wisely** - Match natural reading order for your audience
7. **Use colors strategically** - Highlight status, priority, or categories
8. **Start simple** - Add complexity incrementally as needed
